import React, { useState } from 'react';
import {
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Pencil,
  Check,
  Tag,
  Settings,
  CalendarDays,
  ShieldCheck,
  Activity,
  ChevronRight,
  ArrowLeft,
  BellRing
} from 'lucide-react';
import { CLINICAL_STAGES, getOfficialStageActivities } from '../../data/mockSimonData';
import {
  ClinicalStageId,
  Patient,
  RadiotherapySession,
  SessionStatus,
  StageActivity,
  TreatmentFrequency
} from '../../types/simon';

interface PatientDetailViewProps {
  patient: Patient;
  onOpenRequirements: (activity: StageActivity) => void;
  onOpenAddNote: (activity: StageActivity) => void;
  onOpenHistory: () => void;
  onOpenSessionAction?: (session: RadiotherapySession) => void;
  onUpdatePatientStage: (newStageId: ClinicalStageId) => void;
  onUpdateSchemeFrequency?: (frequency: TreatmentFrequency, totalSessions: number) => void;
  onBackToList?: () => void;
}

export const PatientDetailView: React.FC<PatientDetailViewProps> = ({
  patient,
  onOpenRequirements,
  onOpenAddNote,
  onOpenHistory,
  onOpenSessionAction,
  onUpdatePatientStage,
  onUpdateSchemeFrequency,
  onBackToList
}) => {
  // Currently inspected stage in the stepper
  const [viewedStageId, setViewedStageId] = useState<ClinicalStageId>(
    patient.currentStageId
  );

  // In stage 5 (Radioterapia), allow toggling between 'actividades' and 'programacion'
  const [radiotherapyTab, setRadiotherapyTab] = useState<'actividades' | 'programacion'>(
    'programacion'
  );

  const viewedStage =
    CLINICAL_STAGES.find((s) => s.id === viewedStageId) || CLINICAL_STAGES[0];

  const isRadiotherapyStage = viewedStageId === 'radioterapia';

  // Activities for the viewed stage (strictly using official activities for the 6 stages)
  const stageActivities: StageActivity[] =
    patient.activities.length > 0 && viewedStageId === patient.currentStageId
      ? patient.activities
      : getOfficialStageActivities(viewedStageId, patient.id);

  // Calculate completed activities in this stage
  const completedActivitiesCount = stageActivities.filter(
    (a) => a.schedulingStatus === 'Agendada' || a.schedulingStatus === 'Completada'
  ).length;
  const progressPct = Math.round(
    (completedActivitiesCount / stageActivities.length) * 100
  );

  // Radiotherapy sessions metrics & preloaded session schedule
  const prescribed = patient.scheme.totalSessionsPrescribed || 25;
  const sessionsList: RadiotherapySession[] =
    patient.sessions.length > 0
      ? patient.sessions
      : Array.from({ length: prescribed }).map((_, idx): RadiotherapySession => {
          const num = idx + 1;
          let status: SessionStatus = 'Pendiente';
          let administeredDoseGy: number | undefined = undefined;
          let igrtVerification = 'Pendiente programación semanal';
          let patientTolerance: RadiotherapySession['patientTolerance'] = 'Por valorar';

          if (num <= 3) {
            status = 'Realizada';
            administeredDoseGy = patient.scheme.fractionDose;
            igrtVerification = num === 1 ? 'CBCT 3D - Setup OK (<1mm)' : 'Portal Vision kV/kV OK';
            patientTolerance = num === 1 ? 'Excelente / Asintomático' : 'Tolerancia OK';
          } else if (num === 4) {
            status = 'No asiste';
            administeredDoseGy = 0;
            igrtVerification = 'No ejecutada - Paciente notificó ausencia por transporte';
            patientTolerance = 'No valorada';
          } else if (num === 5) {
            status = 'Cancelado';
            administeredDoseGy = 0;
            igrtVerification = 'Cancelada - Mantenimiento preventivo acelerador lineal';
            patientTolerance = 'Tolerancia OK';
          } else if (num <= 8) {
            status = 'Agendado';
            igrtVerification = 'Pendiente previo a entrega de haz';
            patientTolerance = 'Por valorar';
          }

          return {
            id: `SES-DEMO-${idx + 1}`,
            schemeId: patient.scheme.id,
            patientId: patient.id,
            sessionNumber: num,
            totalPrescribed: prescribed,
            scheduledDate: `${((idx * 1 + 28) % 28) + 1}/11/2026`,
            scheduledTime: '08:30 a.m.',
            status,
            administeredDoseGy,
            igrtVerification,
            accelerator: patient.scheme.acceleratorId,
            technologist: 'Tec. Julián Morales',
            patientTolerance
          };
        });

  const scheduled = sessionsList.filter((s) => s.status === 'Agendado' || s.status === 'Programada').length;
  const completed = sessionsList.filter((s) => s.status === 'Realizada').length;
  const pending = sessionsList.filter((s) => s.status === 'Pendiente').length;
  const noAsisteCount = sessionsList.filter((s) => s.status === 'No asiste').length;
  const cancelledCount = sessionsList.filter((s) => s.status === 'Cancelado' || s.status === 'Cancelada').length;
  const sessionProgressPct = Math.round((completed / prescribed) * 100);

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Barra de Navegación Superior: Volver al listado de pacientes */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          {onBackToList && (
            <button
              type="button"
              onClick={onBackToList}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-[#1853A1] bg-white border border-slate-200/90 rounded-xl hover:bg-blue-50/80 hover:border-blue-300 hover:text-[#144484] transition-all shadow-2xs cursor-pointer group"
              title="Volver al listado de pacientes"
            >
              <ArrowLeft className="w-4 h-4 text-[#1853A1] group-hover:-translate-x-0.5 transition-transform" />
              <span>Volver al listado de pacientes</span>
            </button>
          )}
        </div>
      </div>

      <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight -mt-2">
        Detalle Asistencial y Gestión de Pacientes
      </h1>

      {/* Patient Header Banner Card matching Mockups 1, 4, 5, 6 */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs flex flex-col xl:flex-row xl:items-center justify-between gap-6">
        {/* Left Side: Avatar & Patient Details */}
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#1853A1] text-white flex items-center justify-center font-extrabold text-xl shrink-0 shadow-sm">
            {patient.avatarInitials}
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2.5">
              <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
                {patient.name}
              </h2>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 font-medium">
              <span className="font-mono font-semibold text-slate-800">
                {patient.documentType} {patient.documentNumber}
              </span>
              <span>|</span>
              <span>{patient.age} años</span>
              <span>|</span>
              <span>{patient.gender}</span>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
              <span className="text-slate-600 flex items-center gap-1 font-mono">
                📞 {patient.phone}
              </span>
              <button
                onClick={onOpenHistory}
                className="px-2.5 py-1 text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Ver Historia Clínica</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: 4 Metric Badges matching Mockups 1 & 4 */}
        <div className="flex flex-wrap items-center gap-3">
          {/* PROGRAMA */}
          <div className="px-4 py-2.5 rounded-xl bg-rose-50/70 border border-rose-200/80 min-w-[110px] text-center">
            <div className="text-[10px] uppercase font-bold tracking-wider text-rose-600">
              PROGRAMA
            </div>
            <div className="text-sm font-extrabold text-rose-700 mt-0.5">
              {patient.administrative.program}
            </div>
          </div>

          {/* EPS */}
          <div className="px-4 py-2.5 rounded-xl bg-blue-50/70 border border-blue-200/80 min-w-[100px] text-center">
            <div className="text-[10px] uppercase font-bold tracking-wider text-blue-600">
              EPS
            </div>
            <div className="text-sm font-extrabold text-blue-700 mt-0.5">
              {patient.administrative.eps}
            </div>
          </div>

          {/* N° INGRESO */}
          <div className="px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 min-w-[100px] text-center">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
              N° INGRESO
            </div>
            <div className="text-sm font-extrabold text-slate-800 font-mono mt-0.5">
              {patient.administrative.admissionNumber}
            </div>
          </div>

          {/* FECHA INGRESO */}
          <div className="px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 min-w-[110px] text-center">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
              FECHA INGRESO
            </div>
            <div className="text-sm font-extrabold text-slate-800 font-mono mt-0.5">
              {patient.administrative.admissionDate}
            </div>
          </div>
        </div>
      </div>

      {/* Stepper: Seguimiento por Etapas matching Mockup 1 & 4 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <Activity className="w-4 h-4 text-blue-600" />
            <span>Seguimiento por Etapas (Ruta Clínica Secuencial)</span>
          </div>
          <div className="text-xs text-slate-500 font-medium">
            Etapa actual del paciente:{' '}
            <span className="font-bold text-[#1853A1]">
              {CLINICAL_STAGES.find((s) => s.id === patient.currentStageId)?.name}
            </span>
          </div>
        </div>

        {/* Chevron Stage Stepper */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          {CLINICAL_STAGES.map((stage) => {
            const isCurrentPatientStage = patient.currentStageId === stage.id;
            const isInspectingStage = viewedStageId === stage.id;
            const isCompletedStage = stage.order < (CLINICAL_STAGES.find((s) => s.id === patient.currentStageId)?.order || 1);

            return (
              <button
                key={stage.id}
                onClick={() => setViewedStageId(stage.id)}
                className={`relative px-3.5 py-3 rounded-xl border text-left transition-all duration-150 cursor-pointer flex flex-col justify-between ${
                  isInspectingStage
                    ? 'bg-[#1853A1] text-white border-[#144484] shadow-md ring-2 ring-blue-500/20'
                    : isCompletedStage
                    ? 'bg-emerald-50/70 border-emerald-200 text-slate-800 hover:bg-emerald-50'
                    : 'bg-white border-slate-200 text-slate-700 hover:border-blue-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] ${
                      isInspectingStage
                        ? 'bg-white text-[#1853A1]'
                        : isCompletedStage
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isCompletedStage ? '✓' : stage.order}
                  </span>
                  {isCurrentPatientStage && (
                    <span
                      className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded ${
                        isInspectingStage
                          ? 'bg-emerald-400 text-slate-900'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      Actual
                    </span>
                  )}
                </div>
                <div className="mt-2">
                  <div
                    className={`text-xs font-bold leading-tight ${
                      isInspectingStage ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {stage.name}
                  </div>
                  <div
                    className={`text-[10px] truncate mt-0.5 ${
                      isInspectingStage ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    {stage.shortName}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* STAGE-DEPENDENT CONTENT:
          - For Stages 1, 2, 3, 4 (Primera consulta, Laboratorios, Simulación, Planeación):
            EXCLUSIVELY Activities and Requirements, with the 3 administrative fields (ID Esquema, Esquema, Destino) integrated!
          - For Stage 5 (Radioterapia):
            Activities + Dedicated "Programación y frecuencia" management!
          - For Stage 6 (Post-radioterapia):
            Exclusively Post-radiotherapy follow-up activities & requirements.
      */}

      {/* Sub-selector ONLY in Stage 5 (Radioterapia) */}
      {isRadiotherapyStage && (
        <div className="border-b border-slate-200 flex items-center gap-4 text-xs font-semibold text-slate-600">
          <button
            onClick={() => setRadiotherapyTab('programacion')}
            className={`pb-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              radiotherapyTab === 'programacion'
                ? 'border-[#1853A1] text-[#1853A1] font-bold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            <span>Programación y Frecuencia de Radioterapia ({completed}/{prescribed})</span>
          </button>

          <button
            onClick={() => setRadiotherapyTab('actividades')}
            className={`pb-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              radiotherapyTab === 'actividades'
                ? 'border-[#1853A1] text-[#1853A1] font-bold'
                : 'border-transparent hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Actividades y Requisitos de Radioterapia</span>
          </button>
        </div>
      )}

      {/* ACTIVIDADES Y REQUISITOS (Visible for all stages, or when selected in Stage 5) */}
      {(!isRadiotherapyStage || radiotherapyTab === 'actividades') && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden space-y-0">
          {/* Section Header */}
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-slate-400 font-bold">≡</span>
              <h3 className="text-xs font-bold text-slate-900">
                Actividades de la Etapa:{' '}
                <span className="text-[#1853A1] font-extrabold">{viewedStage.name}</span>
              </h3>
            </div>

            {/* Progress Bar matching Mockup 1 */}
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-700 font-mono">
                {completedActivitiesCount} de {stageActivities.length} Completadas ({progressPct}%)
              </span>
              <div className="w-24 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
            </div>
          </div>

          {/* INTEGRATED ADMINISTRATIVE FIELDS (Requerimiento 3: ID Esquema, Esquema, Destino)
              Integrated directly in the same requirements space, NOT as an independent screen! */}
          <div className="p-4 bg-slate-50/70 border-b border-slate-100">
            <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs">
              <div className="text-[10px] uppercase font-bold tracking-wider text-blue-700 flex items-center gap-1.5 mb-2">
                <Tag className="w-3.5 h-3.5 text-blue-600" />
                <span>Datos Administrativos Integrados del Esquema y Destino</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500 block">
                    ID DEL ESQUEMA
                  </span>
                  <div className="text-xs font-bold text-blue-800 font-mono mt-0.5">
                    {patient.scheme.id}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500 block">
                    ESQUEMA
                  </span>
                  <div className="text-xs font-bold text-slate-800 truncate mt-0.5" title={patient.scheme.treatmentName}>
                    {patient.scheme.treatmentName}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                  <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500 block">
                    DESTINO
                  </span>
                  <div className="text-xs font-bold text-slate-800 truncate mt-0.5">
                    {patient.scheme.acceleratorId}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Activities Table matching Mockups */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/70 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-5">Actividad</th>
                  <th className="py-3 px-4">Estado de Agendamiento</th>
                  <th className="py-3 px-4">Requisitos</th>
                  <th className="py-3 px-5 text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stageActivities.map((activity) => {
                  const reqCompleted = activity.requirements.filter((r) => r.isCompleted).length;
                  const reqTotal = activity.requirements.length || 3;
                  const isScheduled = activity.schedulingStatus === 'Agendada';

                  return (
                    <tr key={activity.id} className="hover:bg-slate-50/50 transition-colors">
                      {/* Actividad */}
                      <td className="py-4 px-5">
                        <div className="flex items-start gap-3">
                          <div
                            className={`p-2 rounded-xl mt-0.5 ${
                              isScheduled
                                ? 'bg-blue-50 text-blue-600'
                                : 'bg-amber-50 text-amber-600'
                            }`}
                          >
                            <Calendar className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 text-xs">
                              {activity.name}
                            </div>
                            <div className="text-[11px] text-slate-500 font-medium">
                              {activity.category}
                            </div>
                            {activity.stageStepNumber && (
                              <span className="text-[9px] text-slate-400 font-mono font-semibold">
                                {activity.stageStepNumber}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Estado de Agendamiento matching Mockups */}
                      <td className="py-4 px-4 whitespace-nowrap">
                        {isScheduled ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold text-xs">
                            <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" />
                            <span>
                              Agendada {activity.scheduledDate} - {activity.scheduledTime}
                            </span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-semibold text-xs">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>Pendiente Sin agendamiento</span>
                          </span>
                        )}
                      </td>

                      {/* Requisitos (Opens RequirementsModal) */}
                      <td className="py-4 px-4 whitespace-nowrap">
                        <button
                          onClick={() => onOpenRequirements(activity)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Ver requisitos</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            ({reqCompleted}/{reqTotal})
                          </span>
                        </button>
                      </td>

                      {/* Acciones (Opens AddNoteModal) */}
                      <td className="py-4 px-5 text-right whitespace-nowrap">
                        <button
                          onClick={() => onOpenAddNote(activity)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 hover:text-blue-700 transition-colors shadow-2xs cursor-pointer"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          <span>Agregar nota</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Activity Notes Section if any exist */}
          {patient.notes.length > 0 && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/50">
              <div className="font-bold text-xs text-slate-800 mb-2.5 flex items-center gap-1.5">
                <Pencil className="w-3.5 h-3.5 text-blue-600" />
                <span>Notas Clínicas y Administrativas Registradas</span>
              </div>
              <div className="space-y-2">
                {patient.notes.map((note) => (
                  <div
                    key={note.id}
                    className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <div className="font-semibold text-slate-900">{note.activityName}</div>
                      <div className="text-slate-600 mt-0.5">{note.text}</div>
                    </div>
                    <div className="text-[11px] text-slate-400 shrink-0 font-mono sm:text-right">
                      {note.registeredBy} • {note.date} - {note.time}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* STAGE 5 ONLY: PROGRAMACIÓN Y FRECUENCIA DE RADIOTERAPIA */}
      {isRadiotherapyStage && radiotherapyTab === 'programacion' && (
        <div className="space-y-6">
          {/* Key Metrics Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
              <span className="text-[10px] uppercase font-bold text-slate-500">PRESCRITAS</span>
              <div className="text-xl font-extrabold text-slate-900 font-mono mt-1">
                {prescribed}
              </div>
              <span className="text-[10px] text-slate-400">Total clínico</span>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
              <span className="text-[10px] uppercase font-bold text-blue-600">AGENDADAS</span>
              <div className="text-xl font-extrabold text-blue-700 font-mono mt-1">
                {scheduled}
              </div>
              <span className="text-[10px] text-blue-500">En agenda</span>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
              <span className="text-[10px] uppercase font-bold text-emerald-600">REALIZADAS</span>
              <div className="text-xl font-extrabold text-emerald-700 font-mono mt-1">
                {completed}
              </div>
              <span className="text-[10px] text-emerald-500">Dosis aplicada</span>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
              <span className="text-[10px] uppercase font-bold text-amber-600">PENDIENTES</span>
              <div className="text-xl font-extrabold text-amber-700 font-mono mt-1">
                {pending}
              </div>
              <span className="text-[10px] text-amber-500">Por programar</span>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
              <span className="text-[10px] uppercase font-bold text-rose-600">NO ASISTE / CANCEL</span>
              <div className="text-xl font-extrabold text-rose-700 font-mono mt-1">
                {noAsisteCount + cancelledCount}
              </div>
              <span className="text-[10px] text-rose-500 font-medium">
                {noAsisteCount} No asiste • {cancelledCount} Cancel
              </span>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs text-center">
              <span className="text-[10px] uppercase font-bold text-slate-500">AVANCE %</span>
              <div className="text-xl font-extrabold text-[#1853A1] font-mono mt-1">
                {sessionProgressPct}%
              </div>
              <div className="w-full h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden">
                <div
                  className="h-full bg-blue-600 rounded-full transition-all duration-300"
                  style={{ width: `${sessionProgressPct}%` }}
                />
              </div>
            </div>
          </div>

          {/* Treatment Scheme and Frequency Bar (Precargada automáticamente desde Planeación - Sin botón manual) */}
          <div className="p-4.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-[11px] font-bold font-mono">
                    {patient.scheme.id}
                  </span>
                  <span className="text-xs font-bold text-slate-900">
                    {patient.scheme.treatmentName}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs text-slate-600">
                  <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <Activity className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                        DOSIS PRECARGADA DE PLANEACIÓN
                      </span>
                      <span className="text-slate-800 font-mono font-bold">
                        {patient.scheme.prescribedDoseTotal} Gy Total
                      </span>{' '}
                      <span className="text-slate-500 font-sans">
                        ({patient.scheme.fractionDose} Gy/fx)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <CalendarDays className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                        FRECUENCIA DE PLANEACIÓN
                      </span>
                      <strong className="text-slate-800 font-semibold">
                        {patient.scheme.frequency}
                      </strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                        DESTINO
                      </span>
                      <strong className="text-slate-800 font-semibold">
                        {patient.scheme.acceleratorId}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>

              <div className="shrink-0 self-start lg:self-center">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Datos cargados desde el esquema de planeación</span>
                </span>
              </div>
            </div>
          </div>

          {/* Alerta Destacada de Próxima Cita (Requerimiento Simón Radioterapia) */}
          {(() => {
            const nextAppointmentSession = sessionsList.find(
              (s) => s.isNextAppointment || (s.status === 'Agendado' && s.sessionNumber === 7)
            ) || sessionsList.find((s) => s.status === 'Agendado');

            if (!nextAppointmentSession) return null;

            return (
              <div className="p-4 rounded-2xl bg-amber-50/90 border-2 border-amber-300 shadow-xs flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <BellRing className="w-5 h-5 animate-pulse" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-900 font-extrabold text-[10px] tracking-wider uppercase">
                      Alerta Asistencial • Próxima Cita
                    </span>
                    <span className="text-xs font-bold text-amber-900">
                      Sesión #{nextAppointmentSession.sessionNumber} programada
                    </span>
                  </div>
                  <p className="text-xs text-amber-950 font-medium mt-1">
                    El paciente tiene una sesión de radioterapia próxima a realizarse el <strong className="font-bold underline text-amber-950">{nextAppointmentSession.scheduledDate}</strong> a las <strong className="font-bold underline text-amber-950">{nextAppointmentSession.scheduledTime}</strong> en <strong className="font-bold text-amber-950">{nextAppointmentSession.accelerator}</strong>.
                  </p>
                </div>
                <div className="shrink-0 hidden sm:flex items-center gap-2">
                  <span className="px-3 py-1.5 rounded-xl bg-amber-600 text-white font-bold text-xs shadow-xs">
                    {nextAppointmentSession.scheduledDate} • {nextAppointmentSession.scheduledTime}
                  </span>
                </div>
              </div>
            );
          })()}

          {/* Sessions List Table - Vista únicamente de consulta */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-bold text-slate-900">
                  Cronograma Detallado de Sesiones de Radioterapia (Solo Consulta)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Monitoreo asistencial de estados de sesión, verificación IGRT y registro de dosis aplicadas
                </p>
              </div>

              {/* Status Badges Legend */}
              <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-semibold">
                <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Realizada
                </span>
                <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                  Agendado
                </span>
                <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 border border-amber-200">
                  Pendiente
                </span>
                <span className="px-2 py-0.5 rounded-md bg-orange-50 text-orange-700 border border-orange-200">
                  No asiste
                </span>
                <span className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-200">
                  Cancelado
                </span>
              </div>
            </div>

            <div className="overflow-x-auto max-h-[540px]">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="sticky top-0 bg-slate-50 shadow-2xs z-10">
                  <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                    <th className="py-2.5 px-4 w-16">Sesión</th>
                    <th className="py-2.5 px-4">Fecha Programada</th>
                    <th className="py-2.5 px-4">Hora</th>
                    <th className="py-2.5 px-4">Estado</th>
                    <th className="py-2.5 px-4">Dosis (Gy)</th>
                    <th className="py-2.5 px-4">Verificación IGRT</th>
                    <th className="py-2.5 px-4">Tolerancia Clínica</th>
                    <th className="py-2.5 px-4">Equipo / Destino</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sessionsList.map((session) => {
                    const isDone = session.status === 'Realizada';
                    const isAgendado = session.status === 'Agendado' || session.status === 'Programada';
                    const isPendiente = session.status === 'Pendiente';
                    const isNoAsiste = session.status === 'No asiste';
                    const isCancelled = session.status === 'Cancelado' || session.status === 'Cancelada' || session.status === 'Reprogramada';
                    const isNextAppointment = Boolean(session.isNextAppointment);

                    return (
                      <tr
                        key={session.id}
                        className={`transition-colors ${
                          isNextAppointment
                            ? 'bg-amber-50/70 hover:bg-amber-100/60 border-l-4 border-l-amber-500'
                            : 'hover:bg-slate-50/60'
                        }`}
                      >
                        {/* Sesión # */}
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">
                          <div className="flex items-center gap-2">
                            <span>#{session.sessionNumber}</span>
                            {isNextAppointment && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500 text-white text-[9px] font-bold shadow-2xs uppercase tracking-wider animate-pulse">
                                <BellRing className="w-2.5 h-2.5" />
                                <span>Próxima cita</span>
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Fecha Programada */}
                        <td className="py-3 px-4 font-mono text-slate-800">
                          {session.scheduledDate}
                        </td>

                        {/* Hora */}
                        <td className="py-3 px-4 font-mono text-slate-600">
                          {session.scheduledTime}
                        </td>

                        {/* Estado: Agendado, Pendiente, No asiste, Cancelado, Realizada */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          {isDone && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                              <Check className="w-3 h-3 text-emerald-600 stroke-[3]" />
                              <span>Realizada</span>
                            </span>
                          )}
                          {isAgendado && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-800 border border-blue-200">
                              <Calendar className="w-3 h-3 text-blue-600" />
                              <span>Agendado</span>
                            </span>
                          )}
                          {isPendiente && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                              <Clock className="w-3 h-3 text-amber-600" />
                              <span>Pendiente</span>
                            </span>
                          )}
                          {isNoAsiste && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-orange-50 text-orange-800 border border-orange-200">
                              <AlertTriangle className="w-3 h-3 text-orange-600" />
                              <span>No asiste</span>
                            </span>
                          )}
                          {isCancelled && (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-800 border border-rose-200">
                              <AlertTriangle className="w-3 h-3 text-rose-600" />
                              <span>Cancelado</span>
                            </span>
                          )}
                        </td>

                        {/* Dosis (Gy) - Dosis aplicada vs prescrita */}
                        <td className="py-3 px-4 font-mono whitespace-nowrap">
                          {isDone ? (
                            <div className="flex items-center gap-1.5">
                              <span className="font-extrabold text-emerald-700">
                                {session.administeredDoseGy ? `${session.administeredDoseGy.toFixed(2)} Gy` : `${patient.scheme.fractionDose.toFixed(2)} Gy`}
                              </span>
                              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/80 px-1.5 py-0.2 rounded font-sans uppercase">
                                Aplicada
                              </span>
                            </div>
                          ) : isNoAsiste || isCancelled ? (
                            <div className="flex items-center gap-1.5 text-slate-400">
                              <span>0.00 Gy</span>
                              <span className="text-[10px] text-rose-600 font-sans font-medium">
                                (No aplicada)
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 text-slate-600">
                              <span className="font-semibold">
                                {patient.scheme.fractionDose.toFixed(2)} Gy
                              </span>
                              <span className="text-[10px] text-slate-400 font-sans">
                                (Prescrita)
                              </span>
                            </div>
                          )}
                        </td>

                        {/* Verificación IGRT */}
                        <td className="py-3 px-4 text-slate-600 min-w-[200px]">
                          <span
                            className={
                              isDone
                                ? 'text-slate-800 font-medium'
                                : isNoAsiste
                                ? 'text-orange-700 font-medium'
                                : isCancelled
                                ? 'text-rose-700 font-medium'
                                : 'text-slate-500'
                            }
                          >
                            {session.igrtVerification || (isDone ? 'CBCT 3D - Setup OK' : 'Pendiente previo a haz')}
                          </span>
                        </td>

                        {/* Tolerancia Clínica */}
                        <td className="py-3 px-4 text-slate-700 font-medium whitespace-nowrap">
                          {session.patientTolerance}
                        </td>

                        {/* Equipo / Destino */}
                        <td className="py-3 px-4 text-slate-600 font-mono text-[11px] whitespace-nowrap">
                          {session.accelerator || patient.scheme.acceleratorId}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
