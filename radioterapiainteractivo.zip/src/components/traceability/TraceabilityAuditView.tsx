import React, { useState } from 'react';
import {
  History,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  User,
  Calendar,
  Layers,
  FileText,
  Activity
} from 'lucide-react';
import { Patient, TraceabilityEvent } from '../../types/simon';

interface TraceabilityAuditViewProps {
  events: TraceabilityEvent[];
  patients: Patient[];
  onSelectPatient: (patientId: string) => void;
}

export const TraceabilityAuditView: React.FC<TraceabilityAuditViewProps> = ({
  events,
  patients,
  onSelectPatient
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatientId, setSelectedPatientId] = useState<string>('all');
  const [selectedEventType, setSelectedEventType] = useState<string>('all');

  const filteredEvents = events.filter((evt) => {
    if (selectedPatientId !== 'all' && evt.patientId !== selectedPatientId) {
      return false;
    }

    if (selectedEventType !== 'all' && evt.eventType !== selectedEventType) {
      return false;
    }

    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchDesc = evt.description.toLowerCase().includes(term);
      const matchPatient = evt.patientName.toLowerCase().includes(term);
      const matchResp = evt.responsible.toLowerCase().includes(term);
      const matchStage = evt.stage.toLowerCase().includes(term);
      if (!matchDesc && !matchPatient && !matchResp && !matchStage) {
        return false;
      }
    }

    return true;
  });

  const getEventBadge = (type: TraceabilityEvent['eventType']) => {
    switch (type) {
      case 'SESION_REALIZADA':
        return { label: 'Sesión Realizada', color: 'bg-emerald-50 text-emerald-800 border-emerald-200' };
      case 'NOTA_AGREGADA':
        return { label: 'Nota / Novedad', color: 'bg-amber-50 text-amber-800 border-amber-200' };
      case 'ACTIVIDAD_COMPLETADA':
        return { label: 'Actividad Hito', color: 'bg-blue-50 text-blue-800 border-blue-200' };
      case 'ESQUEMA_CONFIGURADO':
        return { label: 'Esquema Dosimétrico', color: 'bg-purple-50 text-purple-800 border-purple-200' };
      case 'AUTORIZACION_VALIDADA':
        return { label: 'Autorización EPS', color: 'bg-teal-50 text-teal-800 border-teal-200' };
      case 'CAMBIO_ETAPA':
        return { label: 'Transición de Etapa', color: 'bg-indigo-50 text-indigo-800 border-indigo-200' };
      default:
        return { label: 'Evento Clínico', color: 'bg-slate-100 text-slate-800 border-slate-200' };
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                Bitácora de Trazabilidad Integral Asistencial
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Auditoría completa de Hitos Clínicos, Actividades, Novedades, Responsables y Timestamps
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-mono">
            {filteredEvents.length} eventos registrados
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="relative min-w-[280px] flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por descripción, novedad, responsable o etapa..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
            <span>Paciente:</span>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none"
            >
              <option value="all">Todos los pacientes</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.documentType} {p.documentNumber})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
            <span>Tipo de Evento:</span>
            <select
              value={selectedEventType}
              onChange={(e) => setSelectedEventType(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none"
            >
              <option value="all">Todos los tipos</option>
              <option value="SESION_REALIZADA">Sesiones Realizadas</option>
              <option value="NOTA_AGREGADA">Notas y Novedades</option>
              <option value="ACTIVIDAD_COMPLETADA">Actividades Completadas</option>
              <option value="ESQUEMA_CONFIGURADO">Esquema / Dosimetría</option>
              <option value="AUTORIZACION_VALIDADA">Autorizaciones EPS</option>
            </select>
          </div>
        </div>
      </div>

      {/* Events Table / Timeline */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4 w-36">Fecha / Hora</th>
                <th className="py-3 px-4">Paciente</th>
                <th className="py-3 px-4">Etapa Clínica</th>
                <th className="py-3 px-3">Tipo de Evento</th>
                <th className="py-3 px-5">Descripción de la Trazabilidad</th>
                <th className="py-3 px-4">Responsable Interviniente</th>
                <th className="py-3 px-4 text-center">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEvents.map((evt) => {
                const badge = getEventBadge(evt.eventType);

                return (
                  <tr key={evt.id} className="hover:bg-slate-50/60 transition-colors">
                    {/* Timestamp */}
                    <td className="py-3.5 px-4 font-mono font-medium text-slate-700 whitespace-nowrap">
                      {evt.timestamp}
                    </td>

                    {/* Patient */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <button
                        onClick={() => onSelectPatient(evt.patientId)}
                        className="font-bold text-slate-900 hover:text-blue-700 transition-colors cursor-pointer text-left"
                      >
                        {evt.patientName}
                      </button>
                    </td>

                    {/* Stage */}
                    <td className="py-3.5 px-4 whitespace-nowrap font-medium text-slate-700">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                        <span>{evt.stage}</span>
                      </span>
                    </td>

                    {/* Event Type Badge */}
                    <td className="py-3.5 px-3 whitespace-nowrap">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${badge.color}`}
                      >
                        {badge.label}
                      </span>
                    </td>

                    {/* Description */}
                    <td className="py-3.5 px-5 text-slate-800 leading-relaxed max-w-md">
                      {evt.description}
                    </td>

                    {/* Responsible */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-semibold text-slate-900">{evt.responsible}</div>
                      <div className="text-[11px] text-slate-500 font-medium">{evt.role}</div>
                    </td>

                    {/* Action */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <button
                        onClick={() => onSelectPatient(evt.patientId)}
                        className="px-2.5 py-1 text-xs font-semibold text-blue-700 hover:text-blue-900 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                      >
                        Ver Detalle
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
