import React, { useState } from 'react';
import {
  Settings,
  Cpu,
  ShieldCheck,
  UserCheck,
  Building,
  BellRing,
  Save,
  Check
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [saved, setSaved] = useState(false);
  const [activeAccelerator, setActiveAccelerator] = useState('TrueBeam 1');

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                Configuración del Sistema SIMÓN Radioterapia
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Parámetros de Aceleradores Lineales, Reglas Administrativas y Catálogos Clínicos
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2 bg-[#1853A1] text-white text-xs font-semibold rounded-xl hover:bg-[#144484] shadow-xs flex items-center gap-1.5 cursor-pointer"
        >
          {saved ? <Check className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}
          <span>{saved ? 'Cambios Guardados' : 'Guardar Preferencias'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Accelerators Config */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
            <Cpu className="w-4 h-4 text-blue-600" />
            <span>Aceleradores Lineales y Salas de Tratamiento</span>
          </div>

          <div className="space-y-3 pt-1 text-xs">
            <div className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/50 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900">Acelerador TrueBeam 1 (Sala 1)</div>
                <div className="text-[11px] text-slate-500">Energías: 6MV, 10MV FFF • IGRT: CBCT 3D/4D • SBRT habilitado</div>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                Operativo
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900">Acelerador Clinac iX (Sala 2)</div>
                <div className="text-[11px] text-slate-500">Energías: 6MV, 15MV, Electrones • IGRT: Portal Vision kV</div>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                Operativo
              </span>
            </div>
          </div>
        </div>

        {/* User Session and SIES ONCO Institution Info */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
            <Building className="w-4 h-4 text-blue-600" />
            <span>Institución Asistencial y Usuario en Sesión</span>
          </div>

          <div className="space-y-2 pt-1 text-xs text-slate-700">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Institución Prestadora:</span>
              <span className="font-bold text-slate-900">SIES ONCO - Unidad Oncológica</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Usuario Activo:</span>
              <span className="font-bold text-blue-800">Brigith Lorena</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Rol del Sistema:</span>
              <span className="font-semibold text-slate-800">Coordinadora Asistencial / Gestor de Caso</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-500">Modo de Operación:</span>
              <span className="font-semibold text-emerald-700">Trazabilidad en Vivo (Demostración Coherente)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
