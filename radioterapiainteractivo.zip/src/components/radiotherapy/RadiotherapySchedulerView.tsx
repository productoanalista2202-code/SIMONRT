import React, { useState } from 'react';
import {
  CalendarDays,
  Clock,
  CheckCircle2,
  RotateCcw,
  AlertOctagon,
  Activity,
  Layers,
  ChevronRight,
  Filter,
  Check
} from 'lucide-react';
import { Patient, RadiotherapySession } from '../../types/simon';

interface RadiotherapySchedulerViewProps {
  patients: Patient[];
  onOpenSessionAction: (session: RadiotherapySession, patientName: string, schemeId: string) => void;
  onSelectPatient: (patientId: string) => void;
}

export const RadiotherapySchedulerView: React.FC<RadiotherapySchedulerViewProps> = ({
  patients,
  onOpenSessionAction,
  onSelectPatient
}) => {
  const [selectedMachine, setSelectedMachine] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Collect all patients who are in Radiotherapy or have active sessions
  const rtPatients = patients.filter(
    (p) => p.currentStageId === 'radioterapia' || p.sessions.length > 0 || p.scheme.totalSessionsCompleted > 0
  );

  // Aggregate clinical metrics
  const totalPrescribed = rtPatients.reduce(
    (sum, p) => sum + (p.scheme.totalSessionsPrescribed || 0),
    0
  );
  const totalCompleted = rtPatients.reduce(
    (sum, p) => sum + (p.scheme.totalSessionsCompleted || 0),
    0
  );
  const totalPending = Math.max(0, totalPrescribed - totalCompleted);
  const totalCancelled = rtPatients.reduce(
    (sum, p) => sum + (p.scheme.totalSessionsCancelled || 0),
    0
  );
  const overallAdvance = totalPrescribed > 0 ? Math.round((totalCompleted / totalPrescribed) * 100) : 0;

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <CalendarDays className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                Programación y Frecuencia de Radioterapia
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Monitoreo de Sesiones Prescritas, Programadas, Realizadas, Novedades y Avance
              </p>
            </div>
          </div>
        </div>

        {/* Machine Switcher */}
        <div className="flex items-center gap-2">
          <select
            value={selectedMachine}
            onChange={(e) => setSelectedMachine(e.target.value)}
            className="py-1.5 px-3 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none shadow-xs"
          >
            <option value="all">Todos los Aceleradores Lineales</option>
            <option value="Acelerador TrueBeam 1">Acelerador TrueBeam 1 (Sala 1)</option>
            <option value="Acelerador Clinac iX">Acelerador Clinac iX (Sala 2)</option>
          </select>
        </div>
      </div>

      {/* Aggregate Metrics KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">
            TOTAL SESIONES PRESCRITAS
          </div>
          <div className="text-2xl font-extrabold text-slate-900 font-mono mt-1">
            {totalPrescribed}
          </div>
          <span className="text-[11px] text-slate-500">Prescripción médica acumulada</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-emerald-600">
            EFECTIVAMENTE REALIZADAS
          </div>
          <div className="text-2xl font-extrabold text-emerald-700 font-mono mt-1">
            {totalCompleted}
          </div>
          <span className="text-[11px] text-emerald-600 font-medium">Con verificación IGRT</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-amber-600">
            SESIONES PENDIENTES
          </div>
          <div className="text-2xl font-extrabold text-amber-700 font-mono mt-1">
            {totalPending}
          </div>
          <span className="text-[11px] text-amber-600 font-medium">Por impartir en agenda</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-rose-600">
            CANCEL / REPROGRAMADAS
          </div>
          <div className="text-2xl font-extrabold text-rose-700 font-mono mt-1">
            {totalCancelled}
          </div>
          <span className="text-[11px] text-rose-600 font-medium">Novedad de transporte o clínica</span>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-blue-600">
            AVANCE GLOBAL DEL CICLO
          </div>
          <div className="text-2xl font-extrabold text-[#1853A1] font-mono mt-1">
            {overallAdvance}%
          </div>
          <div className="w-full h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-full transition-all"
              style={{ width: `${overallAdvance}%` }}
            />
          </div>
        </div>
      </div>

      {/* Patient Radiotherapy Cards List */}
      <div className="space-y-4">
        {rtPatients
          .filter(
            (p) =>
              selectedMachine === 'all' ||
              p.scheme.acceleratorId.includes(selectedMachine)
          )
          .map((patient) => {
            const completed = patient.scheme.totalSessionsCompleted || 0;
            const prescribed = patient.scheme.totalSessionsPrescribed || 25;
            const pct = Math.min(100, Math.round((completed / prescribed) * 100));

            return (
              <div
                key={patient.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-4"
              >
                {/* Patient summary row */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#1853A1] font-bold text-sm flex items-center justify-center shrink-0">
                      {patient.avatarInitials}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onSelectPatient(patient.id)}
                          className="font-extrabold text-sm text-slate-900 hover:text-blue-700 transition-colors cursor-pointer"
                        >
                          {patient.name}
                        </button>
                        <span className="text-xs px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 font-mono font-bold">
                          {patient.scheme.id}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 font-medium mt-0.5">
                        {patient.documentType} {patient.documentNumber} • {patient.administrative.eps} • {patient.clinicalDiagnosis}
                      </div>
                    </div>
                  </div>

                  {/* Frequency & Machine Badges */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-center">
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        FRECUENCIA
                      </span>
                      <strong className="text-slate-800">{patient.scheme.frequency}</strong>
                    </div>

                    <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-center">
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">
                        ACELERADOR
                      </span>
                      <strong className="text-slate-800">{patient.scheme.acceleratorId}</strong>
                    </div>

                    <div className="px-4 py-1.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-center min-w-[120px]">
                      <span className="text-[9px] uppercase font-bold text-blue-600 block">
                        AVANCE SESIONES
                      </span>
                      <strong className="text-blue-900 font-mono text-sm">
                        {completed}/{prescribed} ({pct}%)
                      </strong>
                    </div>

                    <button
                      onClick={() => onSelectPatient(patient.id)}
                      className="px-3 py-2 text-xs font-semibold text-white bg-[#1853A1] hover:bg-[#144484] rounded-xl transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                    >
                      <span>Ver Ficha Completa</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                <div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 rounded-full transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>

                {/* Mini Quick Sessions Strip (Sample of next sessions) */}
                <div className="pt-1">
                  <div className="text-[11px] font-bold text-slate-600 mb-2">
                    Visualización Rápida de Sesiones del Esquema:
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                    {Array.from({ length: Math.min(16, prescribed) }).map((_, i) => {
                      const isRealizada = i < completed;
                      const isNext = i === completed;

                      return (
                        <div
                          key={i}
                          onClick={() => {
                            const mockSession: RadiotherapySession = {
                              id: `SES-QUICK-${patient.id}-${i + 1}`,
                              schemeId: patient.scheme.id,
                              patientId: patient.id,
                              sessionNumber: i + 1,
                              totalPrescribed: prescribed,
                              scheduledDate: `${(i % 28) + 1}/11/2026`,
                              scheduledTime: '09:00 a.m.',
                              status: isRealizada ? 'Realizada' : 'Programada',
                              administeredDoseGy: patient.scheme.fractionDose,
                              accelerator: patient.scheme.acceleratorId,
                              technologist: 'Tec. Julián Morales',
                              patientTolerance: 'Tolerancia OK'
                            };
                            onOpenSessionAction(mockSession, patient.name, patient.scheme.id);
                          }}
                          className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                            isRealizada
                              ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 hover:bg-emerald-100'
                              : isNext
                              ? 'bg-blue-50 border-blue-400 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                              : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
                          }`}
                        >
                          <div className="text-[10px] font-mono font-bold">
                            Fx #{i + 1}
                          </div>
                          <div className="text-[9px] font-semibold mt-0.5 truncate">
                            {isRealizada ? '✓ Impartida' : isNext ? 'Próxima' : 'Pendiente'}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
};
