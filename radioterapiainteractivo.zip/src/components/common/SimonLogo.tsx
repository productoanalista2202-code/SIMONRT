import React from 'react';

interface SimonLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const SimonLogo: React.FC<SimonLogoProps> = ({
  className = '',
  size = 'lg'
}) => {
  // Generous, prominent heights to ensure the logo is clearly visible and readable
  const heightClass =
    size === 'sm'
      ? 'h-10'
      : size === 'md'
      ? 'h-13'
      : size === 'xl'
      ? 'h-20'
      : 'h-16'; // default lg is h-16 (64px)

  return (
    <div className={`flex items-center justify-center select-none ${className}`}>
      <img
        src="/assets/aistudio/simon_logo_large.png"
        alt="SIMÓN Radioterapia"
        className={`${heightClass} w-auto max-w-[220px] object-contain drop-shadow-xs transition-transform duration-150`}
        referrerPolicy="no-referrer"
      />
    </div>
  );
};
