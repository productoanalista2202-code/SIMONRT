import React, { useRef, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  User,
  Activity,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Search,
  Filter,
  X
} from 'lucide-react';
import { CLINICAL_STAGES } from '../../data/mockSimonData';
import { ClinicalStageId, Patient } from '../../types/simon';

interface ClinicalKanbanBoardProps {
  patients: Patient[];
  onSelectPatient: (patientId: string) => void;
  onViewStageList: (stageId: ClinicalStageId) => void;
}

export const ClinicalKanbanBoard: React.FC<ClinicalKanbanBoardProps> = ({
  patients,
  onSelectPatient,
  onViewStageList
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEps, setSelectedEps] = useState('all');
  const [selectedProgram, setSelectedProgram] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -340, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 340, behavior: 'smooth' });
    }
  };

  // Distinct programs & EPS from patients
  const availablePrograms = Array.from(
    new Set(patients.map((p) => p.administrative.program).filter(Boolean))
  );

  const availableEps = Array.from(
    new Set(patients.map((p) => p.administrative.eps).filter(Boolean))
  );

  // Filter patients based on criteria
  const filteredPatients = patients.filter((patient) => {
    // Search
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchName = patient.name.toLowerCase().includes(q);
      const matchDoc = patient.documentNumber.includes(q);
      const matchDiag = patient.clinicalDiagnosis.toLowerCase().includes(q);
      const matchEps = patient.administrative.eps.toLowerCase().includes(q);
      if (!matchName && !matchDoc && !matchDiag && !matchEps) return false;
    }

    // EPS filter
    if (selectedEps !== 'all' && patient.administrative.eps !== selectedEps) {
      return false;
    }

    // Program filter
    if (selectedProgram !== 'all' && patient.administrative.program !== selectedProgram) {
      return false;
    }

    // Status filter: Pendiente, Completado, Por agendar
    if (statusFilter !== 'all') {
      const s = statusFilter.toLowerCase();
      const matchTag = patient.tags.some((t) => t.toLowerCase().includes(s));
      const matchAdmin = patient.administrative.administrativeStatus.toLowerCase().includes(s);
      const matchScheme = patient.scheme?.status?.toLowerCase().includes(s);
      const matchAct = patient.activities.some((a) => a.schedulingStatus.toLowerCase().includes(s));
      if (!matchTag && !matchAdmin && !matchScheme && !matchAct) return false;
    }

    return true;
  });

  // Group filtered patients by stage
  const patientsByStage: Record<ClinicalStageId, Patient[]> = {
    primera_consulta: [],
    laboratorios: [],
    simulacion: [],
    planeacion: [],
    radioterapia: [],
    post_radioterapia: []
  };

  filteredPatients.forEach((p) => {
    if (patientsByStage[p.currentStageId]) {
      patientsByStage[p.currentStageId].push(p);
    }
  });

  // Helper for status badge colors matching mockups
  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case 'Completado':
      case 'Completada':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Completado hoy':
      case 'Completado hoy (10/10)':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300 font-bold';
      case 'Por agendar':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Pendiente':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'Pendiente QA':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'En proceso':
      case 'En proceso (80%)':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Header section matching mockups 2 and 4 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-extrabold text-slate-900 tracking-tight uppercase">
            Flujo Clínico de Radioterapia
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Ruta clínica secuencial de atención paso a paso (6 etapas principales)
          </p>
        </div>

        {/* Carousel Prev/Next Buttons */}
        <div className="flex items-center gap-1.5 self-end sm:self-center">
          <button
            onClick={scrollLeft}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-xs transition-colors cursor-pointer"
            title="Desplazar a la izquierda"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={scrollRight}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-xs transition-colors cursor-pointer"
            title="Desplazar a la derecha"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter and Segmentation Bar (Requerimiento Simón Radioterapia: Asegurador, Programa, Estado) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[300px]">
          {/* Búsqueda */}
          <div className="relative min-w-[220px] flex-1 max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por paciente, CC, diagnóstico..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
            />
          </div>

          {/* Asegurador Filter */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Asegurador:</span>
            <select
              value={selectedEps}
              onChange={(e) => setSelectedEps(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">Todos los aseguradores</option>
              <option value="Sura">Sura</option>
              <option value="Sanitas">Sanitas</option>
              <option value="Nueva EPS">Nueva EPS</option>
              <option value="Compensar">Compensar</option>
              <option value="Famisanar">Famisanar</option>
            </select>
          </div>

          {/* Programa Filter */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Programa:</span>
            <select
              value={selectedProgram}
              onChange={(e) => setSelectedProgram(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">Todos los programas</option>
              <option value="CA mama">CA mama</option>
              <option value="Ca. Próstata">Ca. Próstata</option>
              <option value="Pulmón SBRT">Pulmón SBRT</option>
              <option value="Cuello Uterino">Cuello Uterino</option>
              {availablePrograms
                .filter((p) => !['CA mama', 'Ca. Próstata', 'Pulmón SBRT', 'Cuello Uterino'].includes(p))
                .map((prog) => (
                  <option key={prog} value={prog}>
                    {prog}
                  </option>
                ))}
            </select>
          </div>

          {/* Estado Filter: Pendiente, Completado, Por agendar */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Estado:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">Todos los estados</option>
              <option value="Pendiente">Pendiente</option>
              <option value="Completado">Completado</option>
              <option value="Por agendar">Por agendar</option>
            </select>
          </div>
        </div>

        {/* Counter & Reset */}
        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-semibold">
            {filteredPatients.length} pacientes filtrados
          </span>
          {(searchTerm || selectedEps !== 'all' || selectedProgram !== 'all' || statusFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedEps('all');
                setSelectedProgram('all');
                setStatusFilter('all');
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs text-rose-700 bg-rose-50 border border-rose-200 hover:bg-rose-100 transition-colors cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Limpiar filtros</span>
            </button>
          )}
        </div>
      </div>

      {/* Top 6 Step Buttons with patient count badges matching mockups */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {CLINICAL_STAGES.map((stage, idx) => {
          const count = patientsByStage[stage.id]?.length || 0;
          const isPrimary = stage.id === 'primera_consulta';

          return (
            <button
              key={stage.id}
              onClick={() => onViewStageList(stage.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer shadow-xs ${
                isPrimary
                  ? 'bg-[#1853A1] text-white shadow-blue-500/20'
                  : 'bg-white border border-slate-200 text-slate-700 hover:border-blue-400 hover:text-blue-700'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  isPrimary ? 'bg-white text-[#1853A1]' : 'bg-slate-100 text-slate-700'
                }`}
              >
                {stage.order}
              </span>
              <span>{stage.name}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  isPrimary ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Kanban Board Columns Container */}
      <div
        ref={scrollContainerRef}
        className="flex items-start gap-4 overflow-x-auto pb-6 pt-2 scroll-smooth"
      >
        {CLINICAL_STAGES.map((stage) => {
          const stagePatients = patientsByStage[stage.id] || [];
          const isRadiotherapyStage = stage.id === 'radioterapia';

          return (
            <div
              key={stage.id}
              className={`w-[290px] shrink-0 rounded-2xl flex flex-col transition-all duration-200 ${
                isRadiotherapyStage
                  ? 'bg-emerald-50/40 border-2 border-emerald-300 shadow-sm'
                  : 'bg-slate-100/70 border border-slate-200/80'
              }`}
            >
              {/* Column Header */}
              <div className="p-3.5 pb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#1853A1] text-white flex items-center justify-center font-bold text-[11px] shadow-xs">
                    {stage.order}
                  </span>
                  <h3 className="font-bold text-xs text-slate-900 tracking-tight">
                    {stage.name}
                  </h3>
                </div>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-600 shadow-2xs font-mono">
                  {stagePatients.length} pac.
                </span>
              </div>

              {/* Cards List */}
              <div className="p-2 space-y-2.5 flex-1 min-h-[380px]">
                {stagePatients.map((patient) => {
                  const cardStatus =
                    stage.id === 'radioterapia'
                      ? patient.scheme.status === 'Completado'
                        ? 'Completado hoy'
                        : 'En proceso'
                      : patient.tags.includes('Completado')
                      ? 'Completado'
                      : patient.tags.includes('Por agendar')
                      ? 'Por agendar'
                      : patient.tags.includes('Pendiente QA')
                      ? 'Pendiente QA'
                      : patient.tags.includes('Pendiente')
                      ? 'Pendiente'
                      : 'En proceso';

                  // Right tag from mockups
                  const rightTag = patient.tags[0] || 'Asignado';

                  // Radiotherapy progress calculation
                  const prescribed = patient.scheme.totalSessionsPrescribed || 1;
                  const completed = patient.scheme.totalSessionsCompleted || 0;
                  const percent = Math.min(100, Math.round((completed / prescribed) * 100));

                  return (
                    <div
                      key={patient.id}
                      onClick={() => onSelectPatient(patient.id)}
                      className="group bg-white rounded-xl p-3.5 border border-slate-200/90 shadow-xs hover:shadow-md hover:border-blue-400 transition-all duration-150 cursor-pointer text-left relative"
                    >
                      {/* Top Row: Name and chevron */}
                      <div className="flex items-start justify-between gap-1">
                        <div>
                          <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                            {patient.name}
                          </h4>
                          <div className="text-[11px] text-slate-500 font-medium">
                            {patient.documentType} {patient.documentNumber} | {patient.age} años
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all shrink-0 mt-0.5" />
                      </div>

                      {/* Diagnostic / Scheme line */}
                      <div className="mt-1 text-[11px] text-slate-600 truncate font-medium">
                        {patient.administrative.eps} •{' '}
                        {patient.administrative.program || patient.scheme.technique}
                      </div>

                      {/* Radiotherapy Specific Progress Bar if in Stage 5 */}
                      {isRadiotherapyStage && (
                        <div className="mt-2.5 pt-2 border-t border-slate-100">
                          <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 mb-1">
                            <span className="font-mono text-slate-900">
                              {completed}/{prescribed} sesiones
                            </span>
                            <span className="font-mono text-blue-700">
                              {percent}%
                            </span>
                          </div>
                          <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-blue-600 rounded-full transition-all duration-300"
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Bottom row: status pill and right tag */}
                      <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px]">
                        <span
                          className={`px-2 py-0.5 rounded-md font-semibold border ${getStatusBadgeStyle(
                            cardStatus
                          )}`}
                        >
                          {cardStatus}
                        </span>
                        <span className="text-slate-500 font-medium truncate max-w-[110px] text-right">
                          {rightTag}
                        </span>
                      </div>
                    </div>
                  );
                })}

                {stagePatients.length === 0 && (
                  <div className="py-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl bg-white/50">
                    No hay pacientes en esta etapa
                  </div>
                )}
              </div>

              {/* Column Footer: Ver todos (X) → */}
              <div className="p-3 pt-1 text-center">
                <button
                  onClick={() => onViewStageList(stage.id)}
                  className="w-full py-1.5 text-[11px] font-semibold text-blue-700 hover:text-blue-900 hover:bg-blue-50/80 rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>Ver todos ({stagePatients.length})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
