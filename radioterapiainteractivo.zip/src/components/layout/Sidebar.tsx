import React from 'react';
import { LayoutGrid, Settings, UserCheck } from 'lucide-react';
import { SimonLogo } from '../common/SimonLogo';

export type MainNavView = 'tablero' | 'listado' | 'paciente_detalle' | 'configuracion';

interface SidebarProps {
  activeView: MainNavView;
  onNavigate: (view: MainNavView) => void;
  selectedPatientName?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  selectedPatientName
}) => {
  const isTableroActive = activeView === 'tablero' || activeView === 'listado' || activeView === 'paciente_detalle';
  const isConfigActive = activeView === 'configuracion';

  return (
    <aside className="w-64 bg-[#1853A1] text-white flex flex-col shrink-0 min-h-screen border-r border-[#144484] shadow-lg select-none">
      {/* Top Header Box for Logo matching mockups */}
      <div className="bg-white py-4 px-3.5 border-b border-slate-200 flex items-center justify-center shadow-xs">
        <SimonLogo size="lg" />
      </div>

      {/* Navigation matching mockups (Tablero & Configuración) */}
      <div className="px-3 py-5 flex-1 flex flex-col gap-1.5">
        <button
          onClick={() => onNavigate('tablero')}
          className={`w-full flex items-center gap-3.5 px-3.5 py-3 rounded-xl font-medium text-sm transition-all duration-150 text-left cursor-pointer group ${
            isTableroActive
              ? 'bg-white/20 text-white shadow-xs backdrop-blur-xs font-bold'
              : 'text-blue-100/80 hover:bg-white/10 hover:text-white'
          }`}
        >
          <LayoutGrid
            className={`w-5 h-5 shrink-0 transition-transform duration-150 ${
              isTableroActive ? 'text-white scale-105' : 'text-blue-200 group-hover:text-white'
            }`}
          />
          <span className="flex-1 truncate">Tablero</span>
        </button>

        <button
          onClick={() => onNavigate('configuracion')}
          className={`w-full flex items-center gap-3.5 px-3.5 py-3 rounded-xl font-medium text-sm transition-all duration-150 text-left cursor-pointer group ${
            isConfigActive
              ? 'bg-white/20 text-white shadow-xs backdrop-blur-xs font-bold'
              : 'text-blue-100/80 hover:bg-white/10 hover:text-white'
          }`}
        >
          <Settings
            className={`w-5 h-5 shrink-0 transition-transform duration-150 ${
              isConfigActive ? 'text-white scale-105' : 'text-blue-200 group-hover:text-white'
            }`}
          />
          <span className="flex-1 truncate">Configuración</span>
        </button>

        {/* Selected patient indicator when inside Checklist */}
        {activeView === 'paciente_detalle' && selectedPatientName && (
          <div className="mt-6 pt-4 border-t border-white/10 px-2">
            <div className="text-[10px] font-bold text-blue-200 uppercase tracking-wider mb-1.5">
              Paciente en Gestión
            </div>
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-white/15 text-xs text-white">
              <UserCheck className="w-4 h-4 text-emerald-300 shrink-0" />
              <span className="truncate font-bold">{selectedPatientName}</span>
            </div>
          </div>
        )}
      </div>

      {/* Subtle Bottom Footer */}
      <div className="p-4 border-t border-white/10 bg-[#144484]/50 flex items-center justify-between text-[11px] text-blue-200/80">
        <span className="font-medium">SIMÓN Radioterapia</span>
        <span className="font-mono text-[10px] text-blue-300/70">SIES ONCO</span>
      </div>
    </aside>
  );
};
