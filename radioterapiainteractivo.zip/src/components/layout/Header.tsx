import React, { useState } from 'react';
import {
  Search,
  Bell,
  ChevronDown,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { MainNavView } from './Sidebar';

interface HeaderProps {
  activeView: MainNavView;
  onNavigate: (view: MainNavView) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  unreadAlertsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onNavigate,
  searchQuery,
  onSearchChange,
  unreadAlertsCount
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  // Render breadcrumbs matching mockups exactly
  const renderBreadcrumbs = () => {
    if (activeView === 'paciente_detalle') {
      return (
        <nav className="flex items-center gap-1.5 text-xs text-slate-500 font-medium truncate">
          <button
            onClick={() => onNavigate('tablero')}
            className="hover:text-blue-700 transition-colors cursor-pointer"
          >
            Inicio
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <button
            onClick={() => onNavigate('listado')}
            className="hover:text-blue-700 transition-colors cursor-pointer"
          >
            Gestión de Pacientes
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="text-slate-900 font-semibold truncate">
            Detalle Asistencial y Gestión de Pacientes
          </span>
        </nav>
      );
    }

    if (activeView === 'tablero') {
      return (
        <div className="flex flex-col">
          <h1 className="text-sm font-bold text-slate-900 tracking-tight">
            Sistema Integrado de Monitoreo Administrativo y Asistencial
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="w-2 h-2 rounded-full bg-blue-600 inline-block"></span>
            <span>Oncología / Radioterapia</span>
          </div>
        </div>
      );
    }

    if (activeView === 'listado') {
      return (
        <nav className="flex items-center gap-1.5 text-xs text-slate-500 font-medium truncate">
          <button
            onClick={() => onNavigate('tablero')}
            className="hover:text-blue-700 transition-colors cursor-pointer"
          >
            Inicio
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="text-slate-900 font-semibold truncate">
            Gestión de Pacientes (Checklist de Etapa)
          </span>
        </nav>
      );
    }

    return (
      <div className="flex flex-col">
        <h1 className="text-sm font-bold text-slate-900 tracking-tight">
          Configuración del Sistema SIMÓN Radioterapia
        </h1>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span>Aceleradores Lineales y Parámetros Asistenciales</span>
        </div>
      </div>
    );
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between gap-4 sticky top-0 z-20 shadow-xs">
      {/* Left Zone: Breadcrumbs / Title */}
      <div className="min-w-0 max-w-xl">{renderBreadcrumbs()}</div>

      {/* Center Zone: Quick Patient Search */}
      <div className="flex-1 max-w-md hidden md:block">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Buscar paciente por No. Documento o nombre..."
            className="w-full pl-9 pr-4 py-1.5 text-xs bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Right Zone: Notifications & User Profile */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative cursor-pointer"
            title="Novedades y Alertas Asistenciales"
            aria-label="Notificaciones"
          >
            <Bell className="w-5 h-5 text-slate-600" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-rose-500 rounded-full ring-2 ring-white"></span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-30">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-slate-900">
                  Alertas y Novedades Asistenciales
                </span>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded-full">
                  {unreadAlertsCount} activas
                </span>
              </div>
              <div className="divide-y divide-slate-100 text-xs">
                <div className="py-2 flex gap-2.5 items-start">
                  <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-slate-800">Lucía Gómez</div>
                    <div className="text-slate-600 text-[11px]">
                      Inconveniente de transporte. Pendiente reprogramación de consulta.
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Hace 15 min</div>
                  </div>
                </div>
                <div className="py-2 flex gap-2.5 items-start">
                  <Clock className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-slate-800">Sandra Múnera</div>
                    <div className="text-slate-600 text-[11px]">
                      Sesión #8 de 15 ejecutada en TrueBeam 1 (53% completado).
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Hoy 09:15 a.m.</div>
                  </div>
                </div>
                <div className="py-2 flex gap-2.5 items-start">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold text-slate-800">Elena Rodríguez</div>
                    <div className="text-slate-600 text-[11px]">
                      Completó 10/10 sesiones de radioterapia. Lista para Post RT.
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Hoy 10:30 a.m.</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Profile matching mockups */}
        <div className="relative">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2.5 pl-2 pr-1 py-1 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer select-none"
          >
            <div className="w-9 h-9 rounded-full bg-[#1853A1] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              BL
            </div>
            <div className="text-left hidden sm:block">
              <div className="text-xs font-bold text-slate-900 leading-tight">
                Brigith Lorena
              </div>
              <div className="text-[11px] text-slate-500 leading-tight">
                Coordinadora Asistencial
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400" />
          </button>

          {/* Profile Dropdown */}
          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-30 text-xs">
              <div className="p-2 border-b border-slate-100 mb-1">
                <div className="font-bold text-slate-900">Brigith Lorena</div>
                <div className="text-[11px] text-slate-500">Gestor de Caso Oncológico</div>
                <div className="text-[10px] text-blue-700 font-mono mt-0.5">Sies Onco - Sede Central</div>
              </div>
              <button
                onClick={() => {
                  setShowProfileMenu(false);
                  onNavigate('configuracion');
                }}
                className="w-full text-left p-2 rounded-lg hover:bg-slate-50 text-slate-700 font-medium cursor-pointer"
              >
                Configuración
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
