import React, { useState } from 'react';
import {
  Layers,
  FileText,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Database,
  Tag,
  Activity,
  GitBranch,
  BarChart3,
  Search,
  ExternalLink,
  ShieldCheck,
  Calendar,
  Sparkles
} from 'lucide-react';

export const SystemInventoryView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    | 'modulos'
    | 'pantallas'
    | 'campos'
    | 'identificadores'
    | 'etiquetas'
    | 'estados'
    | 'relaciones'
    | 'kpis'
    | 'validacion'
  >('modulos');

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#1853A1] flex items-center justify-center shrink-0">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                Inventario Integral del Sistema SIMÓN Radioterapia
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Especificación Funcional, Catálogo de Entidades, Diccionario de Datos y Matriz de Validación
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200">
            Requerimiento #6 Completado
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="border-b border-slate-200 flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold text-slate-600">
        {[
          { id: 'modulos', label: '1. Módulos y Submódulos', icon: Layers },
          { id: 'pantallas', label: '2. Pantallas y Vistas', icon: FileText },
          { id: 'campos', label: '3. Diccionario de Campos', icon: Database },
          { id: 'identificadores', label: '4. Identificadores Clave', icon: Tag },
          { id: 'etiquetas', label: '5. Etiquetas Administrativas', icon: ShieldCheck },
          { id: 'estados', label: '6. Estados Clínicos y Admin', icon: Activity },
          { id: 'relaciones', label: '7. Relaciones Paciente-Esquema', icon: GitBranch },
          { id: 'kpis', label: '8. Indicadores y Reportes', icon: BarChart3 },
          { id: 'validacion', label: '9. Matriz Mockup vs Validación', icon: HelpCircle }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                isActive
                  ? 'bg-[#1853A1] text-white shadow-xs font-bold'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: MÓDULOS Y SUBMÓDULOS */}
      {activeTab === 'modulos' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                title: 'Módulo 1: Tablero Asistencial (Kanban Clínico)',
                desc: 'Visualización secuencial del recorrido asistencial del paciente a lo largo de las 6 etapas obligatorias.',
                submodules: [
                  'Submódulo de Carrusel y Navegación de Etapas (1 a 6)',
                  'Submódulo de Tarjetas de Paciente con Diagnóstico y EPS',
                  'Submódulo de Barra de Progreso de Sesiones de Radioterapia',
                  'Submódulo de Badges y Etiquetas Asistenciales (TAC OK, Marcadores, etc.)'
                ]
              },
              {
                title: 'Módulo 2: Listado Integral & Checklist de Etapa',
                desc: 'Consolidado tabular de pacientes por etapa con visualización detallada/compacta y checklist interactivo.',
                submodules: [
                  'Submódulo de Filtros Multicriterio (Buscador, Asegurador, Próx. Estado)',
                  'Submódulo de Píldoras de Conteo Rápido (Por agendar, Agendados, En proceso)',
                  'Submódulo de Banner Expandible de Checklist Integral de Etapa',
                  'Submódulo de Tarjetas de Actividad (Completada, Verificada, Próxima Crítica)'
                ]
              },
              {
                title: 'Módulo 3: Detalle Asistencial y Gestión de Pacientes',
                desc: 'Ficha clínica y administrativa integral del paciente con navegación por hitos y requisitos.',
                submodules: [
                  'Submódulo de Banner Cabecera (Avatar, Datos, Programa, EPS, Ingreso)',
                  'Submódulo de Stepper Chevron de Seguimiento por Etapas',
                  'Submódulo de Tabla de Actividades de la Etapa',
                  'Submódulo Modal de Verificación de Requisitos de Actividad',
                  'Submódulo Modal de Registro de Notas y Novedades con Metadatos'
                ]
              },
              {
                title: 'Módulo 4: Gestión de Esquemas de Tratamiento',
                desc: 'Administración de la prescripción médica de radioterapia, dosimetría computarizada y control de calidad.',
                submodules: [
                  'Submódulo de Identificador Único de Esquema (ESQ-ID)',
                  'Submódulo de Parámetros Dosimétricos (Dosis total Gy, Fracción, Técnica)',
                  'Submódulo de Vinculación a Plan TPS (Eclipse/RayStation) y Aprobación DVH',
                  'Submódulo de Asignación de Acelerador Lineal (TrueBeam / Clinac)'
                ]
              },
              {
                title: 'Módulo 5: Programación y Frecuencia de Radioterapia',
                desc: 'Motor de control y calendario de sesiones fraccionadas, cumplimiento y reprogramación con justificación.',
                submodules: [
                  'Submódulo de Configuración de Frecuencia (Diaria L-V, Interdiaria, Semanal)',
                  'Submódulo de Trazabilidad Sesiones Prescritas vs Programadas vs Realizadas',
                  'Submódulo de Registro de Fracción Impartida y Verificación IGRT (CBCT)',
                  'Submódulo de Gestión de Cancelaciones y Reprogramaciones por Causal'
                ]
              },
              {
                title: 'Módulo 6: Auditoría de Trazabilidad Integral',
                desc: 'Registro cronológico inmutable de todos los eventos, intervenciones de usuarios y cambios de estado.',
                submodules: [
                  'Submódulo de Bitácora de Eventos con Timestamps precisos',
                  'Submódulo de Identificación del Responsable y Rol (Oncólogo, Físico, Gestor)',
                  'Submódulo de Registro de Alertas Asistenciales y Novedades de Transporte',
                  'Submódulo de Control de Autorizaciones EPS y Cupos Consumidos'
                ]
              }
            ].map((mod, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <h3 className="font-bold text-xs text-slate-900">{mod.title}</h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{mod.desc}</p>
                  <div className="mt-3 pt-3 border-t border-slate-100">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block mb-1.5">
                      Submódulos Clave:
                    </span>
                    <ul className="space-y-1">
                      {mod.submodules.map((sub, j) => (
                        <li key={j} className="text-[11px] text-slate-700 flex items-start gap-1.5">
                          <span className="text-blue-500 font-bold">•</span>
                          <span>{sub}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PANTALLAS Y VISTAS */}
      {activeTab === 'pantallas' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-900">
              Catálogo de Pantallas y Mapeo con Mockups Oficiales
            </h3>
          </div>
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="py-3 px-4">Pantalla / Vista</th>
                  <th className="py-3 px-4">Referencia de Mockup</th>
                  <th className="py-3 px-4">Objetivo Asistencial</th>
                  <th className="py-3 px-4">Elementos UI Principales</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Tablero Asistencial (Kanban Clínico)
                  </td>
                  <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                    Mockups 2 y 4 (Tablero Asistencial 1 y 2)
                  </td>
                  <td className="py-3 px-4">
                    Visualizar secuencialmente los pacientes distribuidos en las 6 etapas del flujo oncológico.
                  </td>
                  <td className="py-3 px-4">
                    6 columnas con contador, carrusel con flechas, tarjetas de paciente con tags, avance de sesiones (%).
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Listado Integral de Pacientes & Checklist
                  </td>
                  <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                    Mockup 3 (Listado Integral Checklist)
                  </td>
                  <td className="py-3 px-4">
                    Monitorear el avance tabular de actividades de etapa y cumplimiento de hitos para avanzar de fase.
                  </td>
                  <td className="py-3 px-4">
                    Tabla con 11 columnas, selector Detallado/Compacto, banner expandible con 3 tarjetas de actividad.
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Detalle Asistencial y Gestión de Pacientes
                  </td>
                  <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                    Mockup 1 (Detalle Asistencial)
                  </td>
                  <td className="py-3 px-4">
                    Consultar el estado integral de un paciente, su stepper chevron de 6 etapas y sus actividades vigentes.
                  </td>
                  <td className="py-3 px-4">
                    Cabecera con avatar, tags de programa/EPS/ingreso, stepper chevron, tabla de actividades con agendamiento.
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Modal Requisitos de la Actividad
                  </td>
                  <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                    Mockup 5 (Requisitos con Checkbox)
                  </td>
                  <td className="py-3 px-4">
                    Verificar los documentos y condiciones necesarias para ejecutar una actividad asistencial.
                  </td>
                  <td className="py-3 px-4">
                    Checklist interactivo (Orden médica, Autorización EPS, Historia clínica, Laboratorios, Documento ID).
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Modal Agregar Nota u Observación
                  </td>
                  <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                    Mockup 7 (Registro de Notas)
                  </td>
                  <td className="py-3 px-4">
                    Registrar novedades clínicas o administrativas (inasistencias, transporte, reprogramaciones).
                  </td>
                  <td className="py-3 px-4">
                    Caja de texto con contador (500 car.), metadatos automáticos: Registrado por, Fecha y Hora.
                  </td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Monitor de Esquemas & Programación
                  </td>
                  <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                    Requerimientos 2 y 4 (Esquemas y Sesiones)
                  </td>
                  <td className="py-3 px-4">
                    Gestionar los IDs de esquema, dosis total, fraccionamiento, acelerador lineal y frecuencia.
                  </td>
                  <td className="py-3 px-4">
                    Ficha de esquema, matriz de sesiones 1 a N, registro de dosis administrada Gy, verificación IGRT.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: DICCIONARIO DE CAMPOS */}
      {activeTab === 'campos' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-900">
              Diccionario de Datos y Campos de Información
            </h3>
          </div>
          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="py-3 px-4">Entidad</th>
                  <th className="py-3 px-4">Campo</th>
                  <th className="py-3 px-3">Tipo</th>
                  <th className="py-3 px-3">Mandatorio</th>
                  <th className="py-3 px-4">Ejemplo en Mockup</th>
                  <th className="py-3 px-5">Descripción Funcional</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Paciente</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">name</td>
                  <td className="py-2.5 px-3 font-mono">string</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">Lucía Gómez</td>
                  <td className="py-2.5 px-5">Nombre y apellidos completos del paciente.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Paciente</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">documentNumber</td>
                  <td className="py-2.5 px-3 font-mono">string</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">1.026.345.678</td>
                  <td className="py-2.5 px-5">Cédula de ciudadanía o documento de identidad oficial.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Esquema</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">schemeId</td>
                  <td className="py-2.5 px-3 font-mono">string</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">ESQ-2026-0089</td>
                  <td className="py-2.5 px-5">Identificador único del esquema de tratamiento radioterápico.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Esquema</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">technique</td>
                  <td className="py-2.5 px-3 font-mono">enum</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">VMAT, IMRT, 3D-CRT</td>
                  <td className="py-2.5 px-5">Técnica física de entrega de radiación.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Esquema</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">prescribedDoseTotal</td>
                  <td className="py-2.5 px-3 font-mono">number</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">50.0 Gy</td>
                  <td className="py-2.5 px-5">Dosis total absorbida prescrita por el radio-oncólogo.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Esquema</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">frequency</td>
                  <td className="py-2.5 px-3 font-mono">string</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">Diaria (Lunes a Viernes)</td>
                  <td className="py-2.5 px-5">Periodicidad y cadencia clínica de las sesiones.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Sesión</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">sessionNumber</td>
                  <td className="py-2.5 px-3 font-mono">number</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">8 de 15</td>
                  <td className="py-2.5 px-5">Número ordinal de la fracción administrada.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Sesión</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">igrtVerification</td>
                  <td className="py-2.5 px-3 font-mono">string</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-500">Opcional</td>
                  <td className="py-2.5 px-4">CBCT 3D - Setup OK</td>
                  <td className="py-2.5 px-5">Verificación de guiado por imagen previa a la irradiación.</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Administrativo</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">authorizationNumber</td>
                  <td className="py-2.5 px-3 font-mono">string</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">AUT-SURA-992384-26</td>
                  <td className="py-2.5 px-5">Código de autorización emitido por el asegurador (EPS).</td>
                </tr>
                <tr className="hover:bg-slate-50/50">
                  <td className="py-2.5 px-4 font-bold text-slate-900">Actividad</td>
                  <td className="py-2.5 px-4 font-mono text-blue-700">schedulingStatus</td>
                  <td className="py-2.5 px-3 font-mono">enum</td>
                  <td className="py-2.5 px-3 font-semibold text-rose-600">Sí</td>
                  <td className="py-2.5 px-4">Agendada, Pendiente, Por agendar</td>
                  <td className="py-2.5 px-5">Estado operativo de programación de la actividad asistencial.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: IDENTIFICADORES CLAVE */}
      {activeTab === 'identificadores' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                idName: 'ID de Paciente (PAC-ID)',
                format: 'PAC-XXX (e.g. PAC-001)',
                desc: 'Identificador único interno en la base de datos de SIMÓN, independiente del documento oficial para permitir homonimia y trazabilidad histórica.'
              },
              {
                idName: 'ID del Esquema de Tratamiento (ESQ-ID)',
                format: 'ESQ-AAAA-XXXX (e.g. ESQ-2026-0089)',
                desc: 'Identificador único que agrupa la prescripción médica, la técnica dosimétrica (VMAT, IMRT), la dosis total y el conjunto de sesiones asociadas.'
              },
              {
                idName: 'Número de Ingreso Asistencial',
                format: 'Entero secuencial (e.g. 879, 579, 580)',
                desc: 'Identificador del episodio clínico actual de atención oncológica en la sede asistencial SIES ONCO.'
              },
              {
                idName: 'ID del Plan Dosimétrico (PLAN-ID)',
                format: 'PLAN-TECNICA-SITIO-XXX (e.g. PLAN-VMAT-MAMA-042)',
                desc: 'Identificador del archivo de planificación exportado desde el sistema de cálculo TPS (Eclipse, Monaco o RayStation).'
              },
              {
                idName: 'Número de Autorización EPS',
                format: 'AUT-[EPS]-XXXXX-AA (e.g. AUT-SURA-992384-26)',
                desc: 'Código legal emitido por la entidad promotora de salud que respalda la cobertura financiera de las sesiones prescritas.'
              },
              {
                idName: 'Código de Procedimiento CUPS',
                format: '6 dígitos numéricos (e.g. 922415, 922405, 922430)',
                desc: 'Clasificación Única de Procedimientos en Salud para radioterapia conformacional, intensidad modulada o radiocirugía.'
              }
            ].map((idItem, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-xs">{idItem.idName}</h4>
                  <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                    {idItem.format}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">{idItem.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: ETIQUETAS ADMINISTRATIVAS */}
      {activeTab === 'etiquetas' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div>
            <h3 className="text-xs font-bold text-slate-900">
              Catálogo de Etiquetas Administrativas Identificadas en Insumos
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Etiquetas estrictamente delimitadas por los mockups y requerimientos (sin inventar catálogos ajenos)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 block">Aseguradores (EPS):</span>
              <div className="flex flex-wrap gap-1.5">
                {['Sura', 'Sanitas', 'Nueva EPS', 'Compensar', 'Famisanar'].map((e) => (
                  <span key={e} className="px-2 py-0.5 bg-white border border-slate-200 rounded-md font-semibold text-slate-800">
                    {e}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 block">Programas Oncológicos:</span>
              <div className="flex flex-wrap gap-1.5">
                {['CA mama', 'Ca. Próstata', 'Pulmón SBRT', 'Cuello Uterino', 'Cabeza y Cuello'].map((p) => (
                  <span key={p} className="px-2 py-0.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-md font-semibold">
                    {p}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="font-bold text-slate-900 block">Roles Asistenciales / Responsables:</span>
              <div className="space-y-1 text-slate-700">
                <div>• Coordinadora Asistencial (Brigith Lorena)</div>
                <div>• Médico Oncoradioterapeuta (Dr. Morales, Dra. Ruiz)</div>
                <div>• Físico Médico (Físico Rodrigo Salazar)</div>
                <div>• Tecnólogo en Radioterapia (Tec. Julián Morales)</div>
                <div>• Enfermería Oncológica / Trabajo Social</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: ESTADOS CLÍNICOS Y ADMINISTRATIVOS */}
      {activeTab === 'estados' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
              <h4 className="font-bold text-slate-900 text-xs">
                Estados de Etapa Clínica (6 Etapas)
              </h4>
              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-900 font-semibold">1. Primera consulta</div>
                <div className="p-2 rounded-lg bg-slate-50 text-slate-800">2. Laboratorios</div>
                <div className="p-2 rounded-lg bg-slate-50 text-slate-800">3. Simulación</div>
                <div className="p-2 rounded-lg bg-slate-50 text-slate-800">4. Planeación</div>
                <div className="p-2 rounded-lg bg-slate-50 text-slate-800">5. Radioterapia</div>
                <div className="p-2 rounded-lg bg-slate-50 text-slate-800">6. Post-radioterapia</div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
              <h4 className="font-bold text-slate-900 text-xs">
                Estados de Actividades y Agendamiento
              </h4>
              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-800 font-semibold">✔ Agendada (con fecha y hora)</div>
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-800 font-semibold">✔ Completada / Verificada</div>
                <div className="p-2 rounded-lg bg-amber-50 text-amber-800 font-semibold">⏰ Pendiente Sin agendamiento</div>
                <div className="p-2 rounded-lg bg-amber-50 text-amber-800 font-semibold">⏰ Por agendar (Prioridad alta)</div>
                <div className="p-2 rounded-lg bg-blue-50 text-blue-800 font-semibold">⌛ En proceso (80%)</div>
                <div className="p-2 rounded-lg bg-amber-50 text-amber-800 font-semibold">🔬 Pendiente QA</div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
              <h4 className="font-bold text-slate-900 text-xs">
                Estados de Sesiones y Esquemas
              </h4>
              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-800 font-semibold">Realizada (con dosis Gy impartida)</div>
                <div className="p-2 rounded-lg bg-blue-50 text-blue-800 font-semibold">Programada en acelerador</div>
                <div className="p-2 rounded-lg bg-slate-50 text-slate-800 font-semibold">Pendiente en cronograma</div>
                <div className="p-2 rounded-lg bg-amber-50 text-amber-800 font-semibold">Reprogramada (con justificación)</div>
                <div className="p-2 rounded-lg bg-rose-50 text-rose-800 font-semibold">Cancelada (motivo documentado)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: RELACIONES ENTRE PACIENTES, ESQUEMAS Y SESIONES */}
      {activeTab === 'relaciones' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-xs font-bold text-slate-900">
              Modelo Conceptual de Relaciones (Paciente ↔ Esquema ↔ Sesiones ↔ Trazabilidad)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Estructura relacional de datos que garantiza la trazabilidad clínica y administrativa
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4 font-mono text-xs">
            <div className="p-3 bg-white rounded-lg border border-slate-300">
              <strong className="text-blue-800">[PACIENTE]</strong> (1) ─────────── (1..N) <strong className="text-purple-800">[ESQUEMA DE TRATAMIENTO]</strong>
              <div className="text-[11px] text-slate-600 mt-1 font-sans">
                Un paciente oncológico puede tener uno o más esquemas a lo largo de su tratamiento (ej. Esquema Mama Adyuvante + Esquema Boost de Sobreimpresión). Cada esquema tiene su propio identificador único <code>ESQ-ID</code>.
              </div>
            </div>

            <div className="p-3 bg-white rounded-lg border border-slate-300">
              <strong className="text-purple-800">[ESQUEMA]</strong> (1) ─────────── (1) <strong className="text-emerald-800">[PLAN TPS & QA]</strong>
              <div className="text-[11px] text-slate-600 mt-1 font-sans">
                Cada esquema se corresponde con un Plan ID dosimétrico validado en la etapa 4 (Planeación) con control de calidad QA y aprobación de histograma dosis-volumen (DVH).
              </div>
            </div>

            <div className="p-3 bg-white rounded-lg border border-slate-300">
              <strong className="text-purple-800">[ESQUEMA]</strong> (1) ─────────── (N) <strong className="text-blue-800">[SESIONES DE RADIOTERAPIA]</strong>
              <div className="text-[11px] text-slate-600 mt-1 font-sans">
                La prescripción define la cantidad total de fracciones (ej. 25 fracciones) y su periodicidad/frecuencia (ej. Diaria L-V). Se generan N registros de sesión con su estado: Programada, Realizada, Pendiente o Cancelada.
              </div>
            </div>

            <div className="p-3 bg-white rounded-lg border border-slate-300">
              <strong className="text-blue-800">[ETAPA ASISTENCIAL]</strong> (1) ─────────── (N) <strong className="text-amber-800">[ACTIVIDADES]</strong> ─────────── (N) <strong className="text-slate-800">[REQUISITOS]</strong>
              <div className="text-[11px] text-slate-600 mt-1 font-sans">
                Cada una de las 6 etapas contiene sus actividades requeridas. Cada actividad exige el cumplimiento de requisitos previos (orden médica, autorización EPS, laboratorios) para permitir la transición segura a la siguiente fase.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: INDICADORES Y REPORTES */}
      {activeTab === 'kpis' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              kpi: 'Adherencia al Esquema y Cumplimiento Dosimétrico',
              formula: '(Sesiones Realizadas / Sesiones Prescritas) * 100',
              target: '≥ 95% sin interrupciones no programadas',
              utility: 'Evita prolongación indeseada del tiempo total de tratamiento (OTT) que afecta el control tumoral.'
            },
            {
              kpi: 'Tasa de Cancelación / Reprogramación por Transporte',
              formula: '(Sesiones Reprogramadas por Transporte / Total Sesiones) * 100',
              target: '< 3% mensual',
              utility: 'Identifica pacientes vulnerables que requieren articulación con trabajo social y rutas de apoyo.'
            },
            {
              kpi: 'Cumplimiento de Requisitos Previos por Etapa',
              formula: '(Requisitos Verificados / Total Requisitos Mandatorios) * 100',
              target: '100% antes de avanzar a la etapa siguiente',
              utility: 'Garantiza seguridad del paciente e idoneidad jurídica ante la EPS para evitar glosas.'
            },
            {
              kpi: 'Tiempo de Espera entre Simulación y Primer Día de Radioterapia',
              formula: 'Fecha Inicio Radioterapia - Fecha Adquisición TAC Simulación',
              target: '≤ 10 a 14 días hábiles',
              utility: 'Evalúa la eficiencia de los procesos de contorneo, física médica y aseguramiento de calidad QA.'
            },
            {
              kpi: 'Ocupación y Eficiencia de Aceleradores Lineales',
              formula: 'Sesiones Impartidas / Capacidad Nominal de Turnos de Acelerador',
              target: '85% - 90% de capacidad instalada',
              utility: 'Permite optimizar turnos matutinos y vespertinos en TrueBeam 1 y Clinac iX.'
            },
            {
              kpi: 'Consumo de Cupos Autorizados por EPS',
              formula: '(Sesiones Impartidas / Sesiones Autorizadas EPS) * 100',
              target: 'Alerta temprana cuando quedan ≤ 3 sesiones',
              utility: 'Dispara la solicitud de ampliación de autorización antes de que el paciente agote sus cupos.'
            }
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] uppercase font-bold text-blue-700">INDICADOR CLAVE</span>
                <h4 className="font-bold text-slate-900 text-xs mt-1">{item.kpi}</h4>
                <div className="p-2.5 rounded-lg bg-slate-50 font-mono text-[11px] text-slate-800 mt-2">
                  Fórmula: {item.formula}
                </div>
                <div className="text-[11px] text-emerald-800 font-semibold mt-2">
                  Meta esperada: {item.target}
                </div>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  {item.utility}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 9: MATRIZ MOCKUP VS VALIDACIÓN */}
      {activeTab === 'validacion' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-900">
              Matriz Comparativa: Información Respaldada por Mockups vs Requerimientos para Validación Funcional
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Análisis riguroso solicitado en el Requerimiento 6 para alinear al equipo de producto y radio-oncología
            </p>
          </div>

          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                  <th className="py-3 px-4">Componente / Elemento</th>
                  <th className="py-3 px-4">Estado de Respaldo</th>
                  <th className="py-3 px-5">Detalle Respaldado en Mockups</th>
                  <th className="py-3 px-5">Puntos Específicos que Requieren Validación Funcional</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Flujo de 6 Etapas Clínicas
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                      100% Respaldado
                    </span>
                  </td>
                  <td className="py-3 px-5">
                    Las 6 etapas (1. Primera consulta, 2. Laboratorios, 3. Simulación, 4. Planeación, 5. Radioterapia, 6. Post Radioterapia) aparecen explícitas en los Mockups 1, 2, 3 y 4.
                  </td>
                  <td className="py-3 px-5 text-slate-600">
                    Validar si se admiten saltos de etapa o retrocesos asistenciales (ej. Si la simulación requiere repetición por movimiento del paciente).
                  </td>
                </tr>

                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Esquemas de Tratamiento & IDs
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                      Parcial / Requiere Validación
                    </span>
                  </td>
                  <td className="py-3 px-5">
                    El concepto de técnica (VMAT, IMRT, SBRT), conteo de sesiones (8/15) y planes existe en las tarjetas de los mockups 2 y 4.
                  </td>
                  <td className="py-3 px-5 text-slate-600">
                    Definir la estructura final del código <code>ESQ-ID</code>, si soporta múltiples esquemas simultáneos (tratamientos bi-sitio) y la integración con el TPS.
                  </td>
                </tr>

                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Checklist de Requisitos de Actividad
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                      100% Respaldado
                    </span>
                  </td>
                  <td className="py-3 px-5">
                    El modal de requisitos con sus 5 checkboxes (Orden médica, Autorización EPS, Historia clínica, Laboratorios, Documento) está calcado en Mockup 5.
                  </td>
                  <td className="py-3 px-5 text-slate-600">
                    Validar si los requisitos deben ser configurables dinámicamente según la técnica (ej. SBRT requiere TAC 4D adicional).
                  </td>
                </tr>

                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Registro de Notas y Novedades
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
                      100% Respaldado
                    </span>
                  </td>
                  <td className="py-3 px-5">
                    Mockup 7 muestra exactamente la caja de notas, el campo de observación con límite de caracteres y los metadatos de autor, fecha y hora.
                  </td>
                  <td className="py-3 px-5 text-slate-600">
                    Confirmar si las notas deben clasificarse por tipo (administrativa, clínica, de enfermería o física).
                  </td>
                </tr>

                <tr className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Programación y Frecuencia de Sesiones
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                      Enriquecido según Requerimiento 4
                    </span>
                  </td>
                  <td className="py-3 px-5">
                    El avance de sesiones (ej. 8/15 sesiones, 53%) y turnos (Turno mañana, Turno 14:30) se aprecian en el tablero.
                  </td>
                  <td className="py-3 px-5 text-slate-600">
                    Definir la política de recuperación de sesiones cuando hay días festivos o mantenimiento de acelerador lineal.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
