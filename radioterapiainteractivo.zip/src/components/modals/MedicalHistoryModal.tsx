import React from 'react';
import { X, FileText, Activity, ShieldCheck, Stethoscope, AlertCircle, Phone, Calendar } from 'lucide-react';
import { Patient } from '../../types/simon';

interface MedicalHistoryModalProps {
  patient: Patient;
  onClose: () => void;
}

export const MedicalHistoryModal: React.FC<MedicalHistoryModalProps> = ({
  patient,
  onClose
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#1853A1] flex items-center justify-center font-bold text-sm">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Resumen de Historia Clínica Oncológica
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {patient.name} • {patient.documentType} {patient.documentNumber} • {patient.age} años
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
          {/* Diagnostic Banner */}
          <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
            <div className="text-[10px] font-bold uppercase tracking-wider text-blue-700">
              Diagnóstico Principal y Estadificación
            </div>
            <div className="text-sm font-bold text-slate-900 mt-1">
              {patient.clinicalDiagnosis}
            </div>
            <div className="flex flex-wrap gap-4 mt-2 text-xs font-semibold text-slate-700">
              <span className="px-2 py-0.5 rounded-md bg-white border border-blue-200 text-blue-900">
                Estadio TNM: <span className="font-mono">{patient.stagingTNM}</span>
              </span>
              <span className="px-2 py-0.5 rounded-md bg-white border border-blue-200 text-blue-900">
                Intención: {patient.scheme.intent}
              </span>
              <span className="px-2 py-0.5 rounded-md bg-white border border-blue-200 text-blue-900">
                Técnica: {patient.scheme.technique}
              </span>
            </div>
          </div>

          {/* Clinical Context & Scheme */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 space-y-2 bg-slate-50/50">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <Stethoscope className="w-4 h-4 text-blue-600" />
                <span>Prescripción de Radioterapia</span>
              </div>
              <div className="space-y-1.5 pt-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">ID del Esquema:</span>
                  <span className="font-bold font-mono text-blue-700">{patient.scheme.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Dosis Total Prescrita:</span>
                  <span className="font-bold">{patient.scheme.prescribedDoseTotal} Gy</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Dosis por Fracción:</span>
                  <span className="font-bold">{patient.scheme.fractionDose} Gy/fx</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sesiones Prescritas:</span>
                  <span className="font-bold">{patient.scheme.totalSessionsPrescribed} sesiones</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Frecuencia:</span>
                  <span className="font-bold">{patient.scheme.frequency}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Acelerador Asignado:</span>
                  <span className="font-bold text-slate-800">{patient.scheme.acceleratorId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Físico Médico Responsable:</span>
                  <span className="font-medium">{patient.scheme.physicistResponsible}</span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 space-y-2 bg-slate-50/50">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Datos Administrativos y EPS</span>
              </div>
              <div className="space-y-1.5 pt-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Asegurador (EPS):</span>
                  <span className="font-bold text-blue-800">{patient.administrative.eps}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">N° Ingreso:</span>
                  <span className="font-mono font-bold">{patient.administrative.admissionNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Fecha Ingreso:</span>
                  <span className="font-mono">{patient.administrative.admissionDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">N° Autorización:</span>
                  <span className="font-mono font-bold text-emerald-700">{patient.administrative.authorizationNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Sesiones Autorizadas:</span>
                  <span className="font-bold">{patient.administrative.authorizedSessions} de {patient.scheme.totalSessionsPrescribed}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Vigencia Autorización:</span>
                  <span className="font-mono text-slate-700">{patient.administrative.authExpirationDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Teléfono Contacto:</span>
                  <span className="font-medium text-slate-800">{patient.phone}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Notes and Antecedents */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white">
            <div className="font-bold text-slate-900 text-xs mb-2">
              Observaciones Clínicas y Conducta Terapéutica
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Paciente con indicación de radioterapia externa adyuvante. Se completó comité oncológico multidisciplinario. 
              Planificación dosimétrica con protección estricta de órganos críticos circundantes (corazón, pulmones, médula espinal).
              Seguimiento semanal de toxicidad en piel y mucosas durante la etapa de radioterapia activa.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#1853A1] rounded-xl hover:bg-[#144484] shadow-xs cursor-pointer"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
