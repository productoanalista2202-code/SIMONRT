import React, { useState } from 'react';
import { X, Calendar, CheckCircle2, AlertOctagon, RotateCcw, Clock, ShieldCheck, Activity } from 'lucide-react';
import { RadiotherapySession } from '../../types/simon';

interface SessionActionModalProps {
  session: RadiotherapySession;
  patientName: string;
  schemeId: string;
  onClose: () => void;
  onConfirm: (sessionData: {
    sessionId: string;
    action: 'realizar' | 'reprogramar' | 'cancelar';
    date: string;
    time: string;
    administeredDoseGy?: number;
    igrtVerification?: string;
    patientTolerance?: RadiotherapySession['patientTolerance'];
    cancellationReason?: string;
    notes?: string;
  }) => void;
}

export const SessionActionModal: React.FC<SessionActionModalProps> = ({
  session,
  patientName,
  schemeId,
  onClose,
  onConfirm
}) => {
  const [action, setAction] = useState<'realizar' | 'reprogramar' | 'cancelar'>('realizar');
  const [date, setDate] = useState(session.scheduledDate || '10/11/2026');
  const [time, setTime] = useState(session.scheduledTime || '09:00 a.m.');
  const [dose, setDose] = useState<number>(session.administeredDoseGy || 2.0);
  const [igrt, setIgrt] = useState(session.igrtVerification || 'CBCT 3D - Setup y desplazamientos OK (<1mm)');
  const [tolerance, setTolerance] = useState<RadiotherapySession['patientTolerance']>('Tolerancia OK');
  const [reason, setReason] = useState('Inconveniente de transporte');
  const [notes, setNotes] = useState('');

  const handleConfirm = () => {
    onConfirm({
      sessionId: session.id,
      action,
      date,
      time,
      administeredDoseGy: action === 'realizar' ? dose : undefined,
      igrtVerification: action === 'realizar' ? igrt : undefined,
      patientTolerance: action === 'realizar' ? tolerance : undefined,
      cancellationReason: action !== 'realizar' ? reason : undefined,
      notes: notes.trim()
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Gestión de Sesión #{session.sessionNumber} de {session.totalPrescribed}
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Paciente: <span className="text-slate-800 font-bold">{patientName}</span> • Esquema: <span className="font-mono text-blue-700">{schemeId}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Selector */}
        <div className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setAction('realizar')}
              className={`py-2 px-3 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                action === 'realizar'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Realizada</span>
            </button>
            <button
              type="button"
              onClick={() => setAction('reprogramar')}
              className={`py-2 px-3 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                action === 'reprogramar'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reprogramar</span>
            </button>
            <button
              type="button"
              onClick={() => setAction('cancelar')}
              className={`py-2 px-3 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                action === 'cancelar'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <AlertOctagon className="w-4 h-4" />
              <span>Cancelar</span>
            </button>
          </div>

          {action === 'realizar' ? (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 mb-1 block">
                    Fecha de Ejecución
                  </label>
                  <input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 mb-1 block">
                    Hora de Ejecución
                  </label>
                  <input
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 mb-1 block">
                    Dosis Administrada (Gy)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={dose}
                    onChange={(e) => setDose(parseFloat(e.target.value) || 0)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 mb-1 block">
                    Tolerancia del Paciente
                  </label>
                  <select
                    value={tolerance}
                    onChange={(e) => setTolerance(e.target.value as any)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                  >
                    <option value="Excelente / Asintomático">Excelente / Asintomático</option>
                    <option value="Tolerancia OK">Tolerancia OK</option>
                    <option value="Eritema leve G1">Eritema leve G1</option>
                    <option value="Fatiga moderada G2">Fatiga moderada G2</option>
                    <option value="Dermatitis húmeda G3">Dermatitis húmeda G3</option>
                    <option value="Dolor / Náusea">Dolor / Náusea</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 mb-1 block">
                  Verificación Imagenológica IGRT
                </label>
                <input
                  type="text"
                  value={igrt}
                  onChange={(e) => setIgrt(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 mb-1 block">
                  Notas del Tecnólogo / Físico
                </label>
                <input
                  type="text"
                  placeholder="Ej. Paciente cooperador, alineación láser perfecta con tatuajes..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-3 pt-2">
              <div>
                <label className="font-semibold text-slate-700 mb-1 block">
                  Motivo de la {action === 'reprogramar' ? 'Reprogramación' : 'Cancelación'}
                </label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
                >
                  <option value="Inconveniente de transporte">Inconveniente de transporte</option>
                  <option value="Mantenimiento preventivo acelerador">Mantenimiento preventivo acelerador</option>
                  <option value="Toxicidad clínica aguda (descanso médico)">Toxicidad clínica aguda (descanso médico)</option>
                  <option value="Intercurrencia médica / Hospitalización">Intercurrencia médica / Hospitalización</option>
                  <option value="Inasistencia no justificada">Inasistencia no justificada</option>
                  <option value="Trámite pendiente autorización EPS">Trámite pendiente autorización EPS</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 mb-1 block">
                    {action === 'reprogramar' ? 'Nueva Fecha Propuesta' : 'Fecha de Registro'}
                  </label>
                  <input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 mb-1 block">
                    Nueva Hora
                  </label>
                  <input
                    type="text"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 mb-1 block">
                  Detalles de la Novedad
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Detalles sobre comunicación con el paciente, confirmación de nuevo cupo..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 resize-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#1853A1] rounded-xl hover:bg-[#144484] shadow-xs cursor-pointer"
          >
            Confirmar Registro
          </button>
        </div>
      </div>
    </div>
  );
};
