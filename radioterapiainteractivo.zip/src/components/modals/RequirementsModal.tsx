import React, { useState } from 'react';
import { X, FileText, Info, Check, ShieldCheck, Tag, FlaskConical, CheckCircle2 } from 'lucide-react';
import { ActivityRequirement, ClinicalLabResult, StageActivity } from '../../types/simon';
import { DEFAULT_LAB_RESULTS } from '../../data/mockSimonData';

interface RequirementsModalProps {
  activity: StageActivity;
  patientName: string;
  schemeData?: {
    id: string;
    treatmentName: string;
    acceleratorId: string;
  };
  onClose: () => void;
  onSave: (activityId: string, updatedRequirements: ActivityRequirement[]) => void;
}

export const RequirementsModal: React.FC<RequirementsModalProps> = ({
  activity,
  patientName,
  schemeData,
  onClose,
  onSave
}) => {
  const isLabActivity =
    activity.name.toLowerCase().includes('laboratorio') ||
    activity.stageId === 'laboratorios';

  const [labResults, setLabResults] = useState<ClinicalLabResult[]>(
    activity.labResults && activity.labResults.length > 0
      ? activity.labResults
      : DEFAULT_LAB_RESULTS
  );

  const [requirements, setRequirements] = useState<ActivityRequirement[]>(
    activity.requirements.length > 0
      ? activity.requirements
      : isLabActivity
      ? [
          { id: 'REQ-LAB-1', name: 'Hemoglobina: 12.8 g/dL (Normal / Cumplido)', isMandatory: true, isCompleted: true, completedDate: '24/10/2026', completedBy: 'Bacterióloga Patricia Vega' },
          { id: 'REQ-LAB-2', name: 'Creatinina: 0.9 mg/dL - RESULTADO EXAMEN DE CREATININA (Normal / Cumplido)', isMandatory: true, isCompleted: true, completedDate: '24/10/2026', completedBy: 'Dr. Morales' },
          { id: 'REQ-LAB-3', name: 'Leucocitos: 6.2 x 10³/µL (Normal / Cumplido)', isMandatory: true, isCompleted: true, completedDate: '24/10/2026', completedBy: 'Bacterióloga Patricia Vega' }
        ]
      : [
          { id: 'REQ-1', name: 'Orden médica vigente debidamente autorizada.', isMandatory: true, isCompleted: true },
          { id: 'REQ-2', name: 'Autorización de la EPS activa en sistema.', isMandatory: true, isCompleted: true },
          { id: 'REQ-3', name: 'Historia clínica oncológica actualizada.', isMandatory: true, isCompleted: false },
          { id: 'REQ-4', name: 'Documento de identidad validado.', isMandatory: true, isCompleted: true }
        ]
  );

  const toggleLabValidation = (id: string) => {
    setLabResults((prev) =>
      prev.map((lr) =>
        lr.id === id
          ? {
              ...lr,
              isValidated: !lr.isValidated,
              clinicalStatus: !lr.isValidated ? ('Normal / Cumplido' as const) : ('Pendiente' as const),
              validatedBy: !lr.isValidated ? 'Dr. Morales - Oncología Radioterápica' : undefined,
              validationDate: !lr.isValidated ? '24/10/2026 - Validado en consulta' : undefined
            }
          : lr
      )
    );
  };

  const toggleRequirement = (id: string) => {
    setRequirements((prev) =>
      prev.map((req) =>
        req.id === id
          ? {
              ...req,
              isCompleted: !req.isCompleted,
              completedDate: !req.isCompleted ? 'Hoy' : undefined,
              completedBy: !req.isCompleted ? 'Brigith Lorena' : undefined
            }
          : req
      )
    );
  };

  const handleSave = () => {
    onSave(activity.id, requirements);
    onClose();
  };

  const completedCount = requirements.filter((r) => r.isCompleted).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        {/* Header matching mockup 5 */}
        <div className="p-6 pb-4 flex items-start justify-between border-b border-slate-100">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Requisitos de la actividad
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {activity.name} – {activity.category || 'Sies Onco'}
              </p>
              <div className="text-[11px] text-blue-700 font-semibold mt-0.5">
                Paciente: {patientName}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Integrated Administrative Data (Requerimiento 3) */}
          {schemeData && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
              <div className="text-[10px] uppercase font-bold tracking-wider text-blue-700 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5" />
                <span>Datos Administrativos Integrados del Tratamiento</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
                <div className="p-2 rounded-lg bg-white border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium block">ID del Esquema</span>
                  <strong className="text-blue-800 font-mono font-bold">{schemeData.id}</strong>
                </div>
                <div className="p-2 rounded-lg bg-white border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium block">Esquema</span>
                  <strong className="text-slate-800 truncate block" title={schemeData.treatmentName}>
                    {schemeData.treatmentName}
                  </strong>
                </div>
                <div className="p-2 rounded-lg bg-white border border-slate-200">
                  <span className="text-[10px] text-slate-500 font-medium block">Destino</span>
                  <strong className="text-slate-800 truncate block">{schemeData.acceleratorId}</strong>
                </div>
              </div>
            </div>
          )}

          {/* Blue Info Box matching mockup */}
          <div className="p-3.5 rounded-xl bg-blue-50/80 border border-blue-100 flex items-start gap-3 text-xs text-blue-900">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <span className="leading-relaxed">
              {isLabActivity
                ? 'Resultados numéricos y condiciones paraclínicas indispensables para la aptitud del tratamiento oncológico.'
                : 'Documentos y condiciones necesarias para realizar la actividad.'}
            </span>
          </div>

          {/* Dedicated Structured Numerical Laboratory Results Table (Requerimiento Simón Radioterapia) */}
          {isLabActivity && (
            <div className="space-y-3 pt-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                    <FlaskConical className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      Resultados Numéricos de Laboratorio - Sies Onco
                    </h4>
                    <span className="text-[10px] text-slate-500 font-medium">
                      Paraclínicos numéricos estructurados (sin archivos PDF ni documentos adjuntos)
                    </span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                  {labResults.filter((r) => r.isValidated).length} de {labResults.length} Validados
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs bg-white">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="py-2.5 px-3">Examen</th>
                      <th className="py-2.5 px-3 text-center">Resultado</th>
                      <th className="py-2.5 px-3">Unidad</th>
                      <th className="py-2.5 px-3">Fecha</th>
                      <th className="py-2.5 px-3">Estado Clínico</th>
                      <th className="py-2.5 px-3 text-right">Validación Clínica</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {labResults.map((lr) => (
                      <tr key={lr.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-2.5 px-3 font-semibold text-slate-800">
                          <div>{lr.testName}</div>
                          {lr.referenceRange && (
                            <span className="text-[10px] text-slate-400 font-normal">
                              Ref: {lr.referenceRange}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono font-extrabold text-blue-700 text-sm">
                          {lr.numericResult}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600 font-medium">
                          {lr.unit}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                          {lr.resultDate}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              lr.clinicalStatus === 'Normal / Cumplido'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}
                          >
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>{lr.clinicalStatus}</span>
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => toggleLabValidation(lr.id)}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                              lr.isValidated
                                ? 'bg-emerald-600 text-white shadow-2xs hover:bg-emerald-700'
                                : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200'
                            }`}
                          >
                            <Check className="w-3 h-3" />
                            <span>{lr.isValidated ? 'Validado' : 'Validar'}</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Progress counter */}
          <div className="flex items-center justify-between text-xs font-medium text-slate-600 px-1 pt-2">
            <span>{isLabActivity ? 'Requisitos complementarios' : 'Requisitos cumplidos'}</span>
            <span className="font-bold text-slate-900 font-mono">
              {completedCount} de {requirements.length} ({Math.round((completedCount / requirements.length) * 100)}%)
            </span>
          </div>

          {/* Checklist of Requirements */}
          <div className="space-y-2.5 pt-1">
            {requirements.map((req) => (
              <label
                key={req.id}
                onClick={() => toggleRequirement(req.id)}
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer select-none ${
                  req.isCompleted
                    ? 'bg-emerald-50/50 border-emerald-200 text-slate-900'
                    : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 transition-colors mt-0.5 ${
                    req.isCompleted
                      ? 'bg-emerald-600 text-white'
                      : 'border-2 border-slate-300 bg-white'
                  }`}
                >
                  {req.isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
                <div className="text-xs flex-1">
                  <div className={`font-medium ${req.isCompleted ? 'text-slate-900 font-semibold' : 'text-slate-700'}`}>
                    {req.name}
                  </div>
                  {req.isMandatory && (
                    <span className="text-[10px] text-amber-700 font-semibold tracking-wide">
                      Requisito mandatorio
                    </span>
                  )}
                  {req.completedDate && (
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      Verificado por {req.completedBy || 'Admisiones'} • {req.completedDate}
                    </div>
                  )}
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Footer buttons matching mockup */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Cerrar
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#1853A1] rounded-xl hover:bg-[#144484] shadow-xs transition-colors cursor-pointer"
          >
            Actualizar requisitos
          </button>
        </div>
      </div>
    </div>
  );
};
