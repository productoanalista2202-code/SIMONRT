import React, { useState } from 'react';
import { X, Pencil, Calendar, Clock, User } from 'lucide-react';
import { StageActivity } from '../../types/simon';

interface AddNoteModalProps {
  activity: StageActivity;
  patientName: string;
  onClose: () => void;
  onSave: (noteData: {
    activityId: string;
    activityName: string;
    text: string;
    registeredBy: string;
    date: string;
    time: string;
  }) => void;
}

export const AddNoteModal: React.FC<AddNoteModalProps> = ({
  activity,
  patientName,
  onClose,
  onSave
}) => {
  const [noteText, setNoteText] = useState(
    'El paciente no asistió a la cita por inconveniente de transporte. Se contacta para reprogramación.'
  );

  const registeredBy = 'Brigith Lorena';
  const currentDate = '03/11/2026';
  const currentTime = '03:41 p.m.';

  const handleSave = () => {
    if (!noteText.trim()) return;

    onSave({
      activityId: activity.id,
      activityName: `${activity.name} – ${activity.category || 'Sies Onco'}`,
      text: noteText.trim(),
      registeredBy,
      date: currentDate,
      time: currentTime
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all">
        {/* Header matching mockup 7 */}
        <div className="p-6 pb-4 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-50 text-[#1853A1]">
              <Pencil className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Agregar Nota</h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Paciente: <span className="text-slate-800 font-semibold">{patientName}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Activity Identifier Box */}
          <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-100 flex items-center gap-2.5 text-xs text-blue-900 font-semibold">
            <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              Actividad:{' '}
              <span className="font-normal">
                {activity.name} – {activity.category || 'Sies Onco'}
              </span>
            </span>
          </div>

          {/* Text Area Field */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-800">
                Nota u Observación <span className="text-rose-500">*</span>
              </label>
              <span className="text-[11px] font-mono text-slate-400">
                {noteText.length}/500
              </span>
            </div>
            <textarea
              rows={4}
              maxLength={500}
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="Describa la novedad clínica, justificación de inasistencia o reprogramación..."
              className="w-full p-3.5 text-xs text-slate-800 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all leading-relaxed resize-none shadow-xs"
            />
          </div>

          {/* Three Metadata Badges matching mockup 7 */}
          <div className="grid grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600 shrink-0" />
              <div className="min-w-0">
                <div className="text-[9px] uppercase tracking-wider font-bold text-slate-500">
                  REGISTRADO POR
                </div>
                <div className="text-xs font-bold text-slate-900 truncate">
                  {registeredBy}
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
              <div className="min-w-0">
                <div className="text-[9px] uppercase tracking-wider font-bold text-slate-500">
                  FECHA
                </div>
                <div className="text-xs font-bold text-slate-900 truncate font-mono">
                  {currentDate}
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600 shrink-0" />
              <div className="min-w-0">
                <div className="text-[9px] uppercase tracking-wider font-bold text-slate-500">
                  HORA
                </div>
                <div className="text-xs font-bold text-slate-900 truncate font-mono">
                  {currentTime}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer buttons matching mockup */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!noteText.trim()}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#1853A1] rounded-xl hover:bg-[#144484] shadow-xs transition-colors cursor-pointer disabled:opacity-50"
          >
            Guardar Nota
          </button>
        </div>
      </div>
    </div>
  );
};
