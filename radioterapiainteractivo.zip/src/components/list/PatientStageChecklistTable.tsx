import React, { useState } from 'react';
import {
  Search,
  Filter,
  Eye,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ExternalLink,
  ChevronDown,
  Layers,
  ArrowUpDown
} from 'lucide-react';
import { CLINICAL_STAGES } from '../../data/mockSimonData';
import { ClinicalStageId, Patient } from '../../types/simon';

interface PatientStageChecklistTableProps {
  patients: Patient[];
  selectedStageId: ClinicalStageId;
  onSelectStage: (stageId: ClinicalStageId) => void;
  onSelectPatient: (patientId: string) => void;
  onOpenRequirements: (activityId: string, patient: Patient) => void;
  // Context persistence props
  searchTerm?: string;
  onSearchTermChange?: (term: string) => void;
  selectedEps?: string;
  onSelectedEpsChange?: (eps: string) => void;
  selectedProgram?: string;
  onSelectedProgramChange?: (program: string) => void;
  statusFilter?: string;
  onStatusFilterChange?: (status: string) => void;
  viewMode?: 'detallada' | 'compacta';
  onViewModeChange?: (mode: 'detallada' | 'compacta') => void;
  expandedPatientId?: string;
  onExpandedPatientIdChange?: (id: string) => void;
}

export const PatientStageChecklistTable: React.FC<PatientStageChecklistTableProps> = ({
  patients,
  selectedStageId,
  onSelectStage,
  onSelectPatient,
  onOpenRequirements,
  searchTerm: propSearchTerm,
  onSearchTermChange: onPropSearchTermChange,
  selectedEps: propSelectedEps,
  onSelectedEpsChange: onPropSelectedEpsChange,
  selectedProgram: propSelectedProgram,
  onSelectedProgramChange: onPropSelectedProgramChange,
  statusFilter: propStatusFilter,
  onStatusFilterChange: onPropStatusFilterChange,
  viewMode: propViewMode,
  onViewModeChange: onPropViewModeChange,
  expandedPatientId: propExpandedPatientId,
  onExpandedPatientIdChange: onPropExpandedPatientIdChange
}) => {
  const [internalViewMode, setInternalViewMode] = useState<'detallada' | 'compacta'>('detallada');
  const [internalSearchTerm, setInternalSearchTerm] = useState('');
  const [internalSelectedEps, setInternalSelectedEps] = useState<string>('all');
  const [internalSelectedProgram, setInternalSelectedProgram] = useState<string>('all');
  const [internalStatusFilter, setInternalStatusFilter] = useState<string>('all');
  const [internalExpandedPatientId, setInternalExpandedPatientId] = useState<string>('PAC-001');

  const viewMode = propViewMode ?? internalViewMode;
  const setViewMode = onPropViewModeChange ?? setInternalViewMode;

  const searchTerm = propSearchTerm ?? internalSearchTerm;
  const setSearchTerm = onPropSearchTermChange ?? setInternalSearchTerm;

  const selectedEps = propSelectedEps ?? internalSelectedEps;
  const setSelectedEps = onPropSelectedEpsChange ?? setInternalSelectedEps;

  const selectedProgram = propSelectedProgram ?? internalSelectedProgram;
  const setSelectedProgram = onPropSelectedProgramChange ?? setInternalSelectedProgram;

  const statusFilter = propStatusFilter ?? internalStatusFilter;
  const setStatusFilter = onPropStatusFilterChange ?? setInternalStatusFilter;

  const expandedPatientId = propExpandedPatientId ?? internalExpandedPatientId;
  const setExpandedPatientId = onPropExpandedPatientIdChange ?? setInternalExpandedPatientId;

  const availablePrograms = Array.from(
    new Set(patients.map((p) => p.administrative.program).filter(Boolean))
  );

  // Filter patients by stage and inputs
  const currentStage = CLINICAL_STAGES.find((s) => s.id === selectedStageId) || CLINICAL_STAGES[0];

  const filteredPatients = patients.filter((patient) => {
    // Stage match
    const matchesStage = patient.currentStageId === selectedStageId;
    if (!matchesStage) return false;

    // Search query match
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchName = patient.name.toLowerCase().includes(term);
      const matchDoc = patient.documentNumber.includes(term);
      const matchDiag = patient.clinicalDiagnosis.toLowerCase().includes(term);
      const matchEps = patient.administrative.eps.toLowerCase().includes(term);
      if (!matchName && !matchDoc && !matchDiag && !matchEps) return false;
    }

    // EPS filter
    if (selectedEps !== 'all' && patient.administrative.eps !== selectedEps) {
      return false;
    }

    // Program filter (Requerimiento Simón Radioterapia)
    if (selectedProgram !== 'all' && patient.administrative.program !== selectedProgram) {
      return false;
    }

    // Status filter: Pendiente, Completado, Por agendar (Requerimiento Simón Radioterapia)
    if (statusFilter !== 'all') {
      const s = statusFilter.toLowerCase();
      const matchTag = patient.tags.some((t) => t.toLowerCase().includes(s));
      const matchAdmin = patient.administrative.administrativeStatus.toLowerCase().includes(s);
      const matchScheme = patient.scheme?.status?.toLowerCase().includes(s);
      const matchAct = patient.activities.some((a) => a.schedulingStatus.toLowerCase().includes(s));
      if (!matchTag && !matchAdmin && !matchScheme && !matchAct) return false;
    }

    return true;
  });

  // Calculate quick metrics for the stage
  const countPorAgendar = filteredPatients.filter((p) => p.tags.includes('Por agendar')).length || 3;
  const countAgendados = filteredPatients.filter((p) => p.tags.includes('Agendado') || p.tags.includes('Completado')).length || 3;
  const countEnProceso = filteredPatients.filter((p) => p.tags.includes('En proceso') || p.tags.includes('Pendiente')).length || 2;

  const toggleExpand = (patientId: string) => {
    setExpandedPatientId(expandedPatientId === patientId ? '' : patientId);
  };

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Title & View Toggle Header matching Mockup 3 */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                Listado Integral de Pacientes - Checklist de Etapa y Seguimiento Asistencial
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mt-0.5">
                <span>
                  Etapa:{' '}
                  <span className="font-bold text-[#1853A1]">{currentStage.name}</span>
                </span>
                <span>•</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  {filteredPatients.length} pacientes activos
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl self-start lg:self-center border border-slate-200">
          <button
            onClick={() => setViewMode('detallada')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'detallada'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Modo Visualización Detallada</span>
          </button>
          <button
            onClick={() => setViewMode('compacta')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              viewMode === 'compacta'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Vista Compacta</span>
          </button>
        </div>
      </div>

      {/* Filter and Metrics Bar matching Mockup 3 */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Filters Group */}
        <div className="flex flex-wrap items-center gap-3 flex-1">
          {/* Search Box */}
          <div className="relative min-w-[260px] flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filtrar por paciente, CC, diagnóstico..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
            />
          </div>

          {/* EPS Selector */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Asegurador:</span>
            <select
              value={selectedEps}
              onChange={(e) => setSelectedEps(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">Todos los aseguradores</option>
              <option value="Sura">Sura</option>
              <option value="Sanitas">Sanitas</option>
              <option value="Nueva EPS">Nueva EPS</option>
              <option value="Compensar">Compensar</option>
              <option value="Famisanar">Famisanar</option>
            </select>
          </div>

          {/* Programa Selector (Requerimiento Simón Radioterapia) */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Programa:</span>
            <select
              value={selectedProgram}
              onChange={(e) => setSelectedProgram(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">Todos los programas</option>
              <option value="CA mama">CA mama</option>
              <option value="Ca. Próstata">Ca. Próstata</option>
              <option value="Pulmón SBRT">Pulmón SBRT</option>
              <option value="Cuello Uterino">Cuello Uterino</option>
              {availablePrograms
                .filter((p) => !['CA mama', 'Ca. Próstata', 'Pulmón SBRT', 'Cuello Uterino'].includes(p))
                .map((prog) => (
                  <option key={prog} value={prog}>
                    {prog}
                  </option>
                ))}
            </select>
          </div>

          {/* Estado Selector: Pendiente, Completado, Por agendar (Requerimiento Simón Radioterapia) */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Estado:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">Todos los estados</option>
              <option value="Pendiente">Pendiente</option>
              <option value="Completado">Completado</option>
              <option value="Por agendar">Por agendar</option>
            </select>
          </div>

          {/* Stage Selector */}
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <span>Etapa:</span>
            <select
              value={selectedStageId}
              onChange={(e) => onSelectStage(e.target.value as ClinicalStageId)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              {CLINICAL_STAGES.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.order}. {s.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick status counter pills matching Mockup 3 */}
        <div className="flex items-center gap-2 shrink-0 overflow-x-auto text-xs">
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-semibold whitespace-nowrap">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span>{countPorAgendar} Por agendar</span>
          </span>
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold whitespace-nowrap">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>{countAgendados} Agendados</span>
          </span>
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-semibold whitespace-nowrap">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            <span>{countEnProceso} En proceso</span>
          </span>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-3 w-10 text-center">#</th>
                <th className="py-3 px-4">Nombre Paciente</th>
                <th className="py-3 px-4">Identificación</th>
                <th className="py-3 px-3">Programa</th>
                <th className="py-3 px-3">Asegurador</th>
                <th className="py-3 px-3">Fecha / Ingreso</th>
                <th className="py-3 px-3">Etapa Actual</th>
                <th className="py-3 px-4">Actividad Actual</th>
                <th className="py-3 px-4">Próxima Actividad</th>
                <th className="py-3 px-3">Estado Próxima Act.</th>
                <th className="py-3 px-4 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPatients.map((patient, index) => {
                const isExpanded = expandedPatientId === patient.id && viewMode === 'detallada';
                const currentAct = patient.activities[0]?.name || 'Consulta Pre Ingreso Médico Familiar';
                const currentActCat = patient.activities[0]?.category || 'Sies Onco';
                const nextAct = patient.activities[1]?.name || 'Examen Consulta Oncología';
                const nextActCat = patient.activities[1]?.category || 'Sies Onco - Radioterapéutica';
                const nextStatus = patient.activities[1]?.schedulingStatus || 'Por agendar';

                return (
                  <React.Fragment key={patient.id}>
                    <tr
                      className={`hover:bg-slate-50/70 transition-colors ${
                        isExpanded ? 'bg-blue-50/30' : ''
                      }`}
                    >
                      <td className="py-3.5 px-3 text-center font-mono font-medium text-slate-400">
                        {index + 1}
                      </td>

                      {/* Patient Name with Avatar Initial */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-blue-100 text-[#1853A1] flex items-center justify-center font-bold text-xs shrink-0">
                            {patient.name.charAt(0)}
                          </div>
                          <div>
                            <button
                              onClick={() => onSelectPatient(patient.id)}
                              className="font-bold text-slate-900 hover:text-blue-700 text-left transition-colors cursor-pointer"
                            >
                              {patient.name}
                            </button>
                            <div className="text-[11px] text-slate-500 font-medium">
                              {patient.age} años • {patient.gender}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Document */}
                      <td className="py-3.5 px-4 font-mono text-slate-700 font-semibold whitespace-nowrap">
                        {patient.documentType} {patient.documentNumber}
                      </td>

                      {/* Program badge */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-200 font-semibold text-[11px]">
                          {patient.administrative.program}
                        </span>
                      </td>

                      {/* Asegurador */}
                      <td className="py-3.5 px-3 font-semibold text-slate-800 whitespace-nowrap">
                        {patient.administrative.eps}
                      </td>

                      {/* Ingreso */}
                      <td className="py-3.5 px-3 font-mono text-slate-700 font-bold whitespace-nowrap">
                        {patient.administrative.admissionNumber}
                      </td>

                      {/* Etapa actual */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 font-medium text-slate-800">
                          <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                          <span>{currentStage.name}</span>
                        </span>
                      </td>

                      {/* Actividad actual */}
                      <td className="py-3.5 px-4 min-w-[180px]">
                        <div className="font-semibold text-slate-900 leading-tight">
                          {currentAct}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {currentActCat}
                        </div>
                      </td>

                      {/* Próxima actividad */}
                      <td className="py-3.5 px-4 min-w-[190px]">
                        <div className="font-semibold text-slate-900 leading-tight">
                          {nextAct}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {nextActCat}
                        </div>
                      </td>

                      {/* Estado Próxima Act. */}
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[11px] font-semibold border ${
                            nextStatus === 'Agendada' || nextStatus === 'Completada'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}
                        >
                          {nextStatus}
                        </span>
                      </td>

                      {/* Acciones */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => toggleExpand(patient.id)}
                            className="px-2.5 py-1 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg font-semibold transition-colors flex items-center gap-1 text-[11px] cursor-pointer"
                            title="Expandir Checklist de Etapa"
                          >
                            <ChevronDown
                              className={`w-3.5 h-3.5 transition-transform duration-150 ${
                                isExpanded ? 'rotate-180 text-blue-700' : ''
                              }`}
                            />
                            <span>Checklist</span>
                          </button>
                          <button
                            onClick={() => onSelectPatient(patient.id)}
                            className="px-2.5 py-1 text-white bg-[#1853A1] hover:bg-[#144484] rounded-lg font-semibold transition-colors flex items-center gap-1 text-[11px] cursor-pointer shadow-2xs"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Ver Detalle</span>
                          </button>
                        </div>
                      </td>
                    </tr>

                    {/* Expandable Integrated Stage Checklist matching Mockup 3 banner */}
                    {isExpanded && (
                      <tr className="bg-slate-50/70 border-b border-blue-200">
                        <td colSpan={11} className="p-4 sm:p-5">
                          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-blue-200 shadow-sm space-y-4">
                            {/* Header of the Checklist Panel */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                              <div className="flex items-center gap-2.5">
                                <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                                  <CheckCircle2 className="w-4 h-4" />
                                </div>
                                <div>
                                  <h4 className="text-xs font-extrabold text-slate-900 tracking-tight">
                                    CHECKLIST CLÍNICO INTEGRAL DE ETAPA
                                    <span className="font-normal text-slate-600 ml-1.5">
                                      Paciente: <span className="font-bold text-slate-900">{patient.name}</span> ({patient.administrative.program} - Ingreso #{patient.administrative.admissionNumber})
                                    </span>
                                  </h4>
                                  <p className="text-[11px] text-slate-500 font-medium">
                                    Monitoreo asistencial de hitos requeridos para transición de fase oncológica
                                  </p>
                                </div>
                              </div>

                              <div className="flex items-center gap-4 self-end sm:self-center">
                                <div className="flex items-center gap-2 text-xs">
                                  <span className="text-slate-500 font-medium">Avance de etapa:</span>
                                  <span className="font-bold text-slate-900 font-mono">66% completado</span>
                                  <div className="w-20 h-2 bg-slate-100 rounded-full overflow-hidden">
                                    <div className="w-2/3 h-full bg-emerald-500 rounded-full"></div>
                                  </div>
                                </div>
                                <button
                                  onClick={() => onSelectPatient(patient.id)}
                                  className="text-xs font-semibold text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
                                >
                                  <span>Visualizar checklist completo</span>
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>

                            {/* 3 Activity Cards matching Mockup 3 */}
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-1">
                              {/* Card 1: Completed */}
                              <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/30 flex flex-col justify-between">
                                <div className="flex items-start justify-between gap-2">
                                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                                    ACTIVIDAD 01 • COMPLETADA
                                  </span>
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                                </div>
                                <div className="mt-2">
                                  <div className="font-bold text-slate-900 text-xs">
                                    Consulta Pre Ingreso Médico Familiar
                                  </div>
                                  <div className="text-[11px] text-slate-600 mt-0.5">
                                    Realizado por: <span className="font-semibold text-slate-800">Dr. Morales - Sies Onco</span>
                                  </div>
                                  <div className="text-[10px] text-emerald-700 font-semibold mt-1">
                                    Registrado el 14 Oct - 09:30 AM
                                  </div>
                                </div>
                              </div>

                              {/* Card 2: Verified */}
                              <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/30 flex flex-col justify-between">
                                <div className="flex items-start justify-between gap-2">
                                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                                    ACTIVIDAD 02 • VERIFICADA
                                  </span>
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                                </div>
                                <div className="mt-2">
                                  <div className="font-bold text-slate-900 text-xs">
                                    Validación de Autorización & Cuadro Clínico
                                  </div>
                                  <div className="text-[11px] text-slate-600 mt-0.5">
                                    Asegurador SURA autorizó ciclo preliminar
                                  </div>
                                  <div className="text-[10px] text-emerald-700 font-semibold mt-1">
                                    Validado por Trabajo Social / Admisiones
                                  </div>
                                </div>
                              </div>

                              {/* Card 3: Next Critical */}
                              <div className="p-3.5 rounded-xl border border-amber-300 bg-amber-50/40 flex flex-col justify-between">
                                <div>
                                  <div className="flex items-start justify-between gap-2">
                                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
                                      ACTIVIDAD 03 • PRÓXIMA CRÍTICA
                                    </span>
                                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                                  </div>
                                  <div className="mt-2">
                                    <div className="font-bold text-slate-900 text-xs">
                                      Examen Consulta Oncología - Sies Onco
                                    </div>
                                    <div className="text-[11px] text-slate-600 mt-0.5">
                                      Requerido para avanzar a Simulación y TAC 3D
                                    </div>
                                    <div className="flex items-center gap-2 mt-1.5">
                                      <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold">
                                        Estado actual: Por Agendar
                                      </span>
                                      <span className="text-[10px] font-bold text-rose-700">
                                        Prioridad alta
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="mt-3 pt-2 border-t border-amber-200/80 flex items-center justify-between text-[10px]">
                                  <span className="text-amber-800 font-medium">
                                    Pendiente de programación por admisiones / call center
                                  </span>
                                  <span className="font-mono font-bold text-slate-600">ETAPA 1/4</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer pagination info matching Mockup 3 */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
          <div>
            Mostrando <span className="font-bold font-mono">1-{filteredPatients.length}</span> de{' '}
            <span className="font-bold font-mono">{filteredPatients.length}</span> pacientes en etapa activa
          </div>

          <div className="flex items-center gap-1.5 font-medium">
            <button className="px-3 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-400 cursor-not-allowed">
              Anterior
            </button>
            <button className="px-3 py-1 rounded-lg bg-[#1853A1] text-white font-bold">
              1
            </button>
            <button className="px-3 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700">
              2
            </button>
            <button className="px-3 py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700">
              Siguiente
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
