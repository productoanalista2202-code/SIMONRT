import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Search,
  Filter,
  Eye,
  CheckCircle2,
  Clock,
  Activity,
  Layers,
  Calendar,
  AlertCircle,
  Stethoscope
} from 'lucide-react';
import { Patient, RadiotherapyTechnique, SchemeStatus } from '../../types/simon';

interface SchemesManagementViewProps {
  patients: Patient[];
  onSelectPatient: (patientId: string) => void;
}

export const SchemesManagementView: React.FC<SchemesManagementViewProps> = ({
  patients,
  onSelectPatient
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [techniqueFilter, setTechniqueFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const schemesWithPatients = patients.map((p) => ({
    patient: p,
    scheme: p.scheme
  }));

  const filtered = schemesWithPatients.filter(({ patient, scheme }) => {
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchId = scheme.id.toLowerCase().includes(term);
      const matchName = patient.name.toLowerCase().includes(term);
      const matchTreatment = scheme.treatmentName.toLowerCase().includes(term);
      const matchSite = scheme.anatomicalSite.toLowerCase().includes(term);
      const matchDoc = patient.documentNumber.includes(term);
      if (!matchId && !matchName && !matchTreatment && !matchSite && !matchDoc) {
        return false;
      }
    }

    if (techniqueFilter !== 'all' && scheme.technique !== techniqueFilter) {
      return false;
    }

    if (statusFilter !== 'all' && scheme.status !== statusFilter) {
      return false;
    }

    return true;
  });

  return (
    <div className="p-6 space-y-6 max-w-[1720px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
                Gestión y Trazabilidad de Esquemas de Radioterapia
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Identificación de Esquemas (ID), Prescripción Dosimétrica, Sesiones y Máquinas
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-3 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
            {filtered.length} esquemas registrados
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="relative min-w-[280px] flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por ID esquema (ESQ-...), paciente, técnica o sitio..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
            <span>Técnica:</span>
            <select
              value={techniqueFilter}
              onChange={(e) => setTechniqueFilter(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none"
            >
              <option value="all">Todas las técnicas</option>
              <option value="VMAT">VMAT (Arcoterapia)</option>
              <option value="IMRT">IMRT (Intensidad Modulada)</option>
              <option value="3D-CRT">3D-CRT (Conformacional)</option>
              <option value="SBRT">SBRT (Radiocirugía Extracraneal)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
            <span>Estado:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="py-1.5 px-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none"
            >
              <option value="all">Todos los estados</option>
              <option value="En ejecución">En ejecución</option>
              <option value="Aprobado física">Aprobado física</option>
              <option value="En evaluación">En evaluación</option>
              <option value="Completado">Completado</option>
            </select>
          </div>
        </div>
      </div>

      {/* Schemes Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(({ patient, scheme }) => {
          const completed = scheme.totalSessionsCompleted || 0;
          const prescribed = scheme.totalSessionsPrescribed || 1;
          const pct = Math.min(100, Math.round((completed / prescribed) * 100));

          return (
            <div
              key={scheme.id}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between space-y-4"
            >
              {/* Scheme ID & Status Badge */}
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    IDENTIFICADOR ESQUEMA
                  </span>
                  <div className="text-sm font-extrabold text-[#1853A1] font-mono">
                    {scheme.id}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    Plan TPS: <strong>{scheme.planId}</strong>
                  </div>
                </div>

                <span
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                    scheme.status === 'En ejecución'
                      ? 'bg-blue-50 text-blue-800 border-blue-200'
                      : scheme.status === 'Completado'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-amber-50 text-amber-800 border-amber-200'
                  }`}
                >
                  {scheme.status}
                </span>
              </div>

              {/* Patient and Diagnosis */}
              <div>
                <button
                  onClick={() => onSelectPatient(patient.id)}
                  className="font-bold text-slate-900 text-sm hover:text-blue-700 text-left transition-colors cursor-pointer"
                >
                  {patient.name}
                </button>
                <div className="text-xs text-slate-500 font-medium">
                  {patient.documentType} {patient.documentNumber} • {patient.administrative.eps}
                </div>
                <div className="text-xs font-semibold text-slate-700 mt-1 line-clamp-1">
                  {scheme.treatmentName}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Sitio: {scheme.anatomicalSite}
                </div>
              </div>

              {/* Dosimetry & Sessions Progress */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Técnica:</span>
                  <span className="font-bold text-blue-900">{scheme.technique}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Dosis Total:</span>
                  <span className="font-bold font-mono">{scheme.prescribedDoseTotal} Gy ({scheme.fractionDose} Gy/fx)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Frecuencia:</span>
                  <span className="font-semibold text-slate-800">{scheme.frequency}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Acelerador:</span>
                  <span className="font-semibold text-slate-800">{scheme.acceleratorId}</span>
                </div>

                <div className="pt-2 border-t border-slate-200">
                  <div className="flex justify-between font-semibold text-[11px] mb-1">
                    <span>Sesiones impartidas:</span>
                    <span className="font-mono text-blue-700">
                      {completed}/{prescribed} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 rounded-full transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Footer with view detail */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-400">
                  QA: <strong className="text-slate-700">{scheme.qaStatus}</strong>
                </span>
                <button
                  onClick={() => onSelectPatient(patient.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-[#1853A1] hover:text-white hover:bg-[#1853A1] border border-blue-200 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Ver Paciente y Sesiones</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
