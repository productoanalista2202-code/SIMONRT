export type ClinicalStageId =
  | 'primera_consulta'
  | 'laboratorios'
  | 'simulacion'
  | 'planeacion'
  | 'radioterapia'
  | 'post_radioterapia';

export interface ClinicalStageConfig {
  id: ClinicalStageId;
  order: number;
  name: string;
  shortName: string;
  description: string;
  defaultResponsible: string;
}

export type SchemeStatus =
  | 'En evaluación'
  | 'Aprobado física'
  | 'En ejecución'
  | 'Completado'
  | 'Suspendido'
  | 'Reprogramado';

export type RadiotherapyTechnique =
  | '3D-CRT'
  | 'IMRT'
  | 'VMAT'
  | 'SBRT'
  | 'SRS'
  | 'Electrones'
  | 'Braquiterapia';

export type TreatmentIntent =
  | 'Curativa'
  | 'Adyuvante'
  | 'Neoadyuvante'
  | 'Paliativa'
  | 'Concomitante con QT';

export type TreatmentFrequency =
  | 'Diaria (Lunes a Viernes)'
  | 'Interdiaria (L-M-V)'
  | 'Semanal'
  | 'Hiperfraccionada (2 fx/día)'
  | 'Dosis única (Radiocirugía)';

export interface TreatmentScheme {
  id: string; // e.g., 'ESQ-2026-0089'
  patientId: string;
  treatmentName: string;
  technique: RadiotherapyTechnique;
  anatomicalSite: string;
  intent: TreatmentIntent;
  prescribedDoseTotal: number; // in Gray (Gy)
  fractionDose: number; // in Gray (Gy/fx)
  totalSessionsPrescribed: number; // Configurable prescribed sessions
  frequency: TreatmentFrequency;
  totalSessionsScheduled: number;
  totalSessionsCompleted: number;
  totalSessionsPending: number;
  totalSessionsCancelled: number;
  status: SchemeStatus;
  startDatePrescribed: string;
  startDateReal?: string;
  endDateEstimated: string;
  endDateReal?: string;
  planId: string; // TPS plan ID e.g., 'PLAN-VMAT-MAMA-042'
  acceleratorId: string; // Linear accelerator e.g., 'Acelerador TrueBeam 1'
  physicistResponsible: string;
  doctorResponsible: string;
  qaStatus: 'Aprobado' | 'Pendiente QA' | 'En calibración';
  dvhApproved: boolean;
  notes?: string;
}

export type SessionStatus =
  | 'Realizada'
  | 'Agendado'
  | 'Pendiente'
  | 'No asiste'
  | 'Cancelado'
  | 'Programada'
  | 'Cancelada'
  | 'Reprogramada';

export interface RadiotherapySession {
  id: string;
  schemeId: string;
  patientId: string;
  sessionNumber: number;
  totalPrescribed: number;
  scheduledDate: string;
  scheduledTime: string;
  status: SessionStatus;
  actualDate?: string;
  actualTime?: string;
  administeredDoseGy?: number;
  igrtVerification?: string;
  accelerator: string;
  technologist: string;
  patientTolerance:
    | 'Excelente / Asintomático'
    | 'Tolerancia OK'
    | 'Eritema leve G1'
    | 'Fatiga moderada G2'
    | 'Dermatitis húmeda G3'
    | 'Dolor / Náusea'
    | 'No valorada'
    | 'Por valorar';
  cancellationReason?: string;
  notes?: string;
  isNextAppointment?: boolean;
}

export type AdministrativeStatus =
  | 'Autorizado'
  | 'Pendiente autorización'
  | 'En trámite admisiones'
  | 'Requiere ampliación de sesiones'
  | 'Glosado / En revisión'
  | 'Cierre administrativo';

export interface AdministrativeInfo {
  eps: 'Sura' | 'Sanitas' | 'Nueva EPS' | 'Famisanar' | 'Compensar' | 'Salud Total';
  admissionNumber: string; // e.g. "879", "579"
  admissionDate: string; // e.g. "14/10/2026"
  program: string; // e.g. "CA mama", "Ca. Próstata", "Pulmón SBRT", "Cuello Uterino"
  authorizationNumber: string; // e.g. "AUT-SURA-992384-26"
  cupsCode: string; // e.g. "922415 - Radioterapia de Intensidad Modulada VMAT"
  authorizedSessions: number;
  consumedSessions: number;
  authExpirationDate: string;
  administrativeStatus: AdministrativeStatus;
  alerts: string[];
}

export interface ActivityRequirement {
  id: string;
  name: string;
  isMandatory: boolean;
  isCompleted: boolean;
  completedDate?: string;
  completedBy?: string;
}

export interface ActivityNote {
  id: string;
  activityId: string;
  activityName: string;
  text: string;
  registeredBy: string;
  date: string;
  time: string;
}

export type SchedulingStatus =
  | 'Agendada'
  | 'Pendiente'
  | 'Por agendar'
  | 'Completado'
  | 'Completada'
  | 'En proceso'
  | 'Pendiente QA'
  | 'Completado hoy';

export interface ClinicalLabResult {
  id: string;
  testName: string; // e.g. "Hemoglobina", "Creatinina", "Leucocitos"
  numericResult: string; // e.g. "12.8", "0.9", "6.2"
  unit: string; // e.g. "g/dL", "mg/dL", "x 10³/µL"
  referenceRange?: string; // e.g. "12.0 - 15.5 g/dL"
  resultDate: string; // e.g. "24/10/2026"
  clinicalStatus: 'Normal / Cumplido' | 'Fuera de rango' | 'Pendiente';
  isValidated: boolean;
  validatedBy?: string;
  validationDate?: string;
}

export interface StageActivity {
  id: string;
  stageId: ClinicalStageId;
  name: string;
  category: string;
  schedulingStatus: SchedulingStatus;
  scheduledDate?: string;
  scheduledTime?: string;
  responsibleName: string;
  responsibleRole: string;
  requirements: ActivityRequirement[];
  labResults?: ClinicalLabResult[];
  notes: ActivityNote[];
  priority: 'Alta' | 'Media' | 'Baja';
  stageStepNumber?: string; // e.g. "ETAPA 1/4"
  description?: string;
}

export interface TraceabilityEvent {
  id: string;
  timestamp: string;
  patientId: string;
  patientName: string;
  stage: string;
  eventType:
    | 'CAMBIO_ETAPA'
    | 'ACTIVIDAD_COMPLETADA'
    | 'REQUISITOS_ACTUALIZADOS'
    | 'NOTA_AGREGADA'
    | 'SESION_REALIZADA'
    | 'SESION_REPROGRAMADA'
    | 'SESION_CANCELADA'
    | 'ESQUEMA_CONFIGURADO'
    | 'AUTORIZACION_VALIDADA';
  description: string;
  responsible: string;
  role: string;
  previousState?: string;
  newState?: string;
}

export interface Patient {
  id: string; // e.g. 'PAC-001'
  name: string;
  documentType: 'CC' | 'TI' | 'CE' | 'Pasaporte';
  documentNumber: string;
  age: number;
  gender: 'Femenino' | 'Masculino';
  phone: string;
  currentStageId: ClinicalStageId;
  clinicalDiagnosis: string;
  stagingTNM: string;
  administrative: AdministrativeInfo;
  scheme: TreatmentScheme;
  sessions: RadiotherapySession[];
  activities: StageActivity[];
  notes: ActivityNote[];
  tags: string[]; // e.g. "TAC OK", "Turno mañana", "Marcadores", "Física Médica", "Dr. Morales"
  avatarInitials: string;
}
